import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { addDays, isSameDay, isWithinInterval, parseISO } from 'date-fns';
import type { Shift } from '../types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getRecurringShifts(shift: Shift, startDate: Date, endDate: Date): Shift[] {
  if (!shift.recurringId || !shift.recurringDays || !shift.recurringUntil) {
    return [shift];
  }

  const recurringDays = shift.recurringDays.split(',');
  const endRecurring = parseISO(shift.recurringUntil);
  const shifts: Shift[] = [];
  const daysMap: { [key: string]: number } = {
    'Mon': 1, 'Tue': 2, 'Wed': 3, 'Thu': 4, 'Fri': 5, 'Sat': 6, 'Sun': 0
  };

  let currentDate = startDate;
  while (currentDate <= endDate && currentDate <= endRecurring) {
    const dayName = Object.entries(daysMap).find(([_, value]) => value === currentDate.getDay())?.[0];
    if (dayName && recurringDays.includes(dayName)) {
      const shiftStart = parseISO(shift.startTime);
      const shiftEnd = parseISO(shift.endTime);
      const newShiftStart = new Date(currentDate);
      newShiftStart.setHours(shiftStart.getHours(), shiftStart.getMinutes());
      const newShiftEnd = new Date(currentDate);
      newShiftEnd.setHours(shiftEnd.getHours(), shiftEnd.getMinutes());

      shifts.push({
        ...shift,
        id: `${shift.id}-${currentDate.toISOString()}`,
        startTime: newShiftStart.toISOString(),
        endTime: newShiftEnd.toISOString()
      });
    }
    currentDate = addDays(currentDate, 1);
  }

  return shifts;
}

export function getShiftsForDay(shifts: Shift[], date: Date): Shift[] {
  return shifts.flatMap(shift => {
    if (shift.recurringId && shift.recurringDays && shift.recurringUntil) {
      const instances = getRecurringShifts(shift, date, date);
      return instances.filter(instance => {
        const shiftDate = parseISO(instance.startTime);
        return isSameDay(shiftDate, date);
      });
    } else {
      const shiftDate = parseISO(shift.startTime);
      return isSameDay(shiftDate, date) ? [shift] : [];
    }
  });
}

export function getShiftsForRange(shifts: Shift[], startDate: Date, endDate: Date): Shift[] {
  return shifts.flatMap(shift => {
    if (shift.recurringId && shift.recurringDays && shift.recurringUntil) {
      return getRecurringShifts(shift, startDate, endDate);
    } else {
      const shiftDate = parseISO(shift.startTime);
      return isWithinInterval(shiftDate, { start: startDate, end: endDate }) ? [shift] : [];
    }
  });
}