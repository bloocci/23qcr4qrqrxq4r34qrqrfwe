import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBmVMe9z0igXq8dIJCwKvuVZljHFoPol1o",
  authDomain: "shift-b0fc2.firebaseapp.com",
  projectId: "shift-b0fc2",
  storageBucket: "shift-b0fc2.firebasestorage.app",
  messagingSenderId: "1008745935213",
  appId: "1:1008745935213:web:395838c50c1fc2a9c46a64",
  measurementId: "G-N0VCP1F66Y"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Collection references
export const usersCollection = 'users';
export const shiftsCollection = 'shifts';
export const rolesCollection = 'roles';
export const employeesCollection = 'employees';