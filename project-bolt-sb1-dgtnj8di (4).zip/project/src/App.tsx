import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { useEmployeeStore } from './store/employeeStore';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { Schedule } from './pages/Schedule';
import { Employees } from './pages/Employees';
import { Settings } from './pages/Settings';
import { Layout } from './components/Layout';
import { Toaster } from 'sonner';
import { useEffect } from 'react';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuthStore();
  return user ? <>{children}</> : <Navigate to="/login" replace />;
}

function AppContent() {
  const { initAuth, setNavigate, user } = useAuthStore();
  const { fetchEmployees, fetchRoles } = useEmployeeStore();
  const navigate = useNavigate();

  useEffect(() => {
    setNavigate(navigate);
    const cleanup = initAuth();
    return () => {
      setNavigate(null);
      cleanup();
    };
  }, [initAuth, setNavigate, navigate]);

  // Only fetch data when user is authenticated
  useEffect(() => {
    if (user) {
      fetchEmployees().catch(console.error);
      fetchRoles().catch(console.error);
    }
  }, [user, fetchEmployees, fetchRoles]);

  return (
    <>
      <Toaster position="top-right" richColors closeButton />
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route path="/" element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }>
          <Route index element={<Dashboard />} />
          <Route path="schedule" element={<Schedule />} />
          <Route path="employees" element={<Employees />} />
          <Route path="settings" element={<Settings />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}