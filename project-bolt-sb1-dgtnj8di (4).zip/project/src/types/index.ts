// Auth types
export interface User {
  id: string;
  email: string | null;
  role: 'admin' | 'manager';
}

// Schedule types
export interface Shift {
  id: string;
  employeeId: string;
  startTime: string;
  endTime: string;
  title?: string;
  notes?: string;
  type?: string;
  recurringDays?: string;
  recurringUntil?: string;
}

export interface LastShiftSettings {
  isRecurring?: boolean;
  recurringDays?: string[];
  recurringDuration?: number;
  shiftDuration?: number;
  employeeId?: string;
  title?: string;
  notes?: string;
}

export interface ScheduleState {
  shifts: Shift[];
  lastSettings: LastShiftSettings;
  setShifts: (shifts: Shift[]) => void;
  addShift: (shift: Shift) => void;
  updateShift: (shift: Shift) => void;
  deleteShift: (id: string, deleteRecurring?: boolean) => void;
  deleteRecurringShifts: (recurringId: string) => void;
  deleteEmployeeShifts: (employeeId: string) => void;
  setLastSettings: (settings: LastShiftSettings) => void;
  clearLastSettings: () => void;
}

// Employee types
export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email?: string;
  role: Role;
  startDate: string;
  schedule: {
    [key: string]: {
      enabled: boolean;
      timeSlots: any[];
    };
  };
}

export interface Role {
  id: string;
  name: string;
  description: string;
  colorCode: string;
}

export type ViewType = 'timeline' | 'week' | 'month';