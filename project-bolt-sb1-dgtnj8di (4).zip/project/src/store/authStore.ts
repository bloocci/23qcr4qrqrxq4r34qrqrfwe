import { create } from 'zustand';
import { 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User as FirebaseUser 
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { toast } from 'sonner';

interface User {
  id: string;
  email: string | null;
  role: 'admin' | 'manager';
}

interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
  navigate: ((to: string) => void) | null;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setNavigate: (navigate: ((to: string) => void) | null) => void;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  initAuth: () => () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  loading: false,
  error: null,
  navigate: null,

  setUser: (user) => set({ user }),
  setLoading: (loading) => set({ loading }),
  setNavigate: (navigate) => set({ navigate }),

  login: async (email: string, password: string) => {
    set({ loading: true, error: null });
    
    try {
      const { user: firebaseUser } = await signInWithEmailAndPassword(auth, email, password);
      
      // In a real app, you would fetch user role from your backend
      const role = email.includes('admin') ? 'admin' : 'manager';
      
      const user: User = {
        id: firebaseUser.uid,
        email: firebaseUser.email,
        role
      };
      
      set({ user, loading: false });
      
      const navigate = get().navigate;
      if (navigate) {
        navigate('/');
      }
      
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Login failed';
      set({ error: message, loading: false });
      throw error;
    }
  },

  logout: async () => {
    try {
      await signOut(auth);
      set({ user: null, error: null });
      
      const navigate = get().navigate;
      if (navigate) {
        navigate('/login');
      }
      
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Failed to log out');
    }
  },

  initAuth: () => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser: FirebaseUser | null) => {
      if (firebaseUser) {
        // In a real app, fetch user role from your backend
        const role = firebaseUser.email?.includes('admin') ? 'admin' : 'manager';
        
        const user: User = {
          id: firebaseUser.uid,
          email: firebaseUser.email,
          role
        };
        
        set({ user, loading: false });
      } else {
        set({ user: null, loading: false });
      }
    });

    return unsubscribe;
  }
}));