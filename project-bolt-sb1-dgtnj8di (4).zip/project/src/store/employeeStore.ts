import { create } from 'zustand';
import { 
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where
} from 'firebase/firestore';
import { db, employeesCollection, rolesCollection } from '../lib/firebase';
import type { Employee, Role } from '../types';
import { toast } from 'sonner';
import { useAuthStore } from './authStore';

interface EmployeeState {
  employees: Employee[];
  roles: Role[];
  setEmployees: (employees: Employee[]) => void;
  setRoles: (roles: Role[]) => void;
  addEmployee: (employee: Employee) => Promise<void>;
  updateEmployee: (employee: Employee) => Promise<void>;
  deleteEmployee: (id: string) => Promise<void>;
  addRole: (role: Omit<Role, 'id'>) => Promise<void>;
  updateRole: (role: Role) => Promise<void>;
  deleteRole: (id: string) => Promise<void>;
  fetchEmployees: () => Promise<void>;
  fetchRoles: () => Promise<void>;
}

export const useEmployeeStore = create<EmployeeState>((set, get) => ({
  employees: [],
  roles: [],
  
  setEmployees: (employees) => set({ employees }),
  setRoles: (roles) => set({ roles }),
  
  fetchEmployees: async () => {
    const user = useAuthStore.getState().user;
    if (!user) return; // Don't fetch if not authenticated

    try {
      const querySnapshot = await getDocs(collection(db, employeesCollection));
      const employees = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Employee[];
      set({ employees });
    } catch (error) {
      console.error('Error fetching employees:', error);
      // Only show error toast if we're not on the login page
      if (window.location.pathname !== '/login') {
        toast.error('Failed to fetch employees');
      }
    }
  },

  fetchRoles: async () => {
    const user = useAuthStore.getState().user;
    if (!user) return; // Don't fetch if not authenticated

    try {
      const querySnapshot = await getDocs(collection(db, rolesCollection));
      const roles = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Role[];
      set({ roles });
    } catch (error) {
      console.error('Error fetching roles:', error);
      // Only show error toast if we're not on the login page
      if (window.location.pathname !== '/login') {
        toast.error('Failed to fetch roles');
      }
    }
  },
  
  addEmployee: async (employee) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can add employees');
      throw new Error('Permission denied');
    }

    try {
      await setDoc(doc(db, employeesCollection, employee.id), employee);
      const { employees } = get();
      set({ employees: [...employees, employee] });
      toast.success('Employee added successfully');
    } catch (error) {
      console.error('Error adding employee:', error);
      toast.error('Failed to add employee');
      throw error;
    }
  },
  
  updateEmployee: async (employee) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can update employees');
      throw new Error('Permission denied');
    }

    try {
      await updateDoc(doc(db, employeesCollection, employee.id), { ...employee });
      const { employees } = get();
      set({ employees: employees.map(e => e.id === employee.id ? employee : e) });
      toast.success('Employee updated successfully');
    } catch (error) {
      console.error('Error updating employee:', error);
      toast.error('Failed to update employee');
      throw error;
    }
  },
  
  deleteEmployee: async (id) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can delete employees');
      throw new Error('Permission denied');
    }

    try {
      await deleteDoc(doc(db, employeesCollection, id));
      const { employees } = get();
      set({ employees: employees.filter(e => e.id !== id) });
      toast.success('Employee deleted successfully');
    } catch (error) {
      console.error('Error deleting employee:', error);
      toast.error('Failed to delete employee');
      throw error;
    }
  },
  
  addRole: async (roleData) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can add roles');
      throw new Error('Permission denied');
    }

    try {
      const roleRef = doc(collection(db, rolesCollection));
      const role: Role = {
        id: roleRef.id,
        name: roleData.name,
        description: roleData.description,
        colorCode: roleData.colorCode
      };
      
      await setDoc(roleRef, role);
      const { roles } = get();
      set({ roles: [...roles, role] });
      toast.success('Role added successfully');
    } catch (error) {
      console.error('Error adding role:', error);
      toast.error('Failed to add role');
      throw error;
    }
  },
  
  updateRole: async (role) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can update roles');
      throw new Error('Permission denied');
    }

    try {
      await updateDoc(doc(db, rolesCollection, role.id), { ...role });
      const { roles } = get();
      set({ roles: roles.map(r => r.id === role.id ? role : r) });
      toast.success('Role updated successfully');
    } catch (error) {
      console.error('Error updating role:', error);
      toast.error('Failed to update role');
      throw error;
    }
  },
  
  deleteRole: async (id) => {
    const user = useAuthStore.getState().user;
    if (!user || user.role !== 'admin') {
      toast.error('Only administrators can delete roles');
      throw new Error('Permission denied');
    }

    try {
      await deleteDoc(doc(db, rolesCollection, id));
      const { roles } = get();
      set({ roles: roles.filter(r => r.id !== id) });
      toast.success('Role deleted successfully');
    } catch (error) {
      console.error('Error deleting role:', error);
      toast.error('Failed to delete role');
      throw error;
    }
  }
}));