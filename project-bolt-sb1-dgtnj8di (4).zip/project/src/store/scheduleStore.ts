import { create } from 'zustand';
import { 
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  getDocs
} from 'firebase/firestore';
import { db, shiftsCollection } from '../lib/firebase';
import type { Shift, ScheduleState, LastShiftSettings } from '../types';

const initialLastSettings: LastShiftSettings = {
  isRecurring: false,
  recurringDays: [],
  recurringDuration: 30,
  shiftDuration: 1,
  employeeId: '',
  title: '',
  notes: ''
};

export const useScheduleStore = create<ScheduleState>((set, get) => ({
  shifts: [],
  lastSettings: initialLastSettings,
  
  setShifts: (shifts) => set({ shifts }),
  
  addShift: async (shift) => {
    try {
      await setDoc(doc(db, shiftsCollection, shift.id), shift);
      const { shifts } = get();
      set({ shifts: [...shifts, shift] });
    } catch (error) {
      console.error('Error adding shift:', error);
      throw error;
    }
  },
  
  updateShift: async (shift) => {
    try {
      await updateDoc(doc(db, shiftsCollection, shift.id), { ...shift });
      const { shifts } = get();
      set({ shifts: shifts.map(s => s.id === shift.id ? shift : s) });
    } catch (error) {
      console.error('Error updating shift:', error);
      throw error;
    }
  },
  
  deleteShift: async (id, deleteRecurring = false) => {
    try {
      const { shifts } = get();
      const shiftToDelete = shifts.find(s => s.id === id);
      
      if (deleteRecurring && shiftToDelete?.recurringDays) {
        // Delete all recurring shifts
        const q = query(
          collection(db, shiftsCollection),
          where('recurringDays', '==', shiftToDelete.recurringDays)
        );
        const querySnapshot = await getDocs(q);
        const deletePromises = querySnapshot.docs.map(doc => deleteDoc(doc.ref));
        await Promise.all(deletePromises);
        
        set({ shifts: shifts.filter(s => s.recurringDays !== shiftToDelete.recurringDays) });
      } else {
        // Delete single shift
        await deleteDoc(doc(db, shiftsCollection, id));
        set({ shifts: shifts.filter(s => s.id !== id) });
      }
    } catch (error) {
      console.error('Error deleting shift:', error);
      throw error;
    }
  },
  
  deleteRecurringShifts: async (recurringDays) => {
    try {
      const q = query(
        collection(db, shiftsCollection),
        where('recurringDays', '==', recurringDays)
      );
      const querySnapshot = await getDocs(q);
      const deletePromises = querySnapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);
      
      const { shifts } = get();
      set({ shifts: shifts.filter(s => s.recurringDays !== recurringDays) });
    } catch (error) {
      console.error('Error deleting recurring shifts:', error);
      throw error;
    }
  },
  
  deleteEmployeeShifts: async (employeeId) => {
    try {
      const q = query(
        collection(db, shiftsCollection),
        where('employeeId', '==', employeeId)
      );
      const querySnapshot = await getDocs(q);
      const deletePromises = querySnapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);
      
      const { shifts } = get();
      set({ shifts: shifts.filter(s => s.employeeId !== employeeId) });
    } catch (error) {
      console.error('Error deleting employee shifts:', error);
      throw error;
    }
  },

  setLastSettings: (settings) => {
    set({ lastSettings: { ...initialLastSettings, ...settings } });
  },

  clearLastSettings: () => {
    set({ lastSettings: initialLastSettings });
  }
}));