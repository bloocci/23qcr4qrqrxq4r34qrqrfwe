import { create } from 'zustand';
import type { RecruitingState, Candidate, Interview, InterviewerAvailability } from '../types';

// Load data from localStorage or use empty arrays
const loadFromStorage = <T>(key: string, initial: T): T => {
  if (typeof window === 'undefined') return initial;
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) : initial;
};

export const useRecruitingStore = create<RecruitingState>((set) => ({
  candidates: loadFromStorage('candidates', []),
  interviews: loadFromStorage('interviews', []),
  availability: loadFromStorage('availability', []),
  
  setCandidates: (candidates) => {
    set({ candidates });
    localStorage.setItem('candidates', JSON.stringify(candidates));
  },

  addCandidate: (candidate) => set((state) => {
    const candidates = [...state.candidates, candidate];
    localStorage.setItem('candidates', JSON.stringify(candidates));
    return { candidates };
  }),

  updateCandidate: (candidate) => set((state) => {
    const candidates = state.candidates.map((c) => 
      c.id === candidate.id ? candidate : c
    );
    localStorage.setItem('candidates', JSON.stringify(candidates));
    return { candidates };
  }),

  deleteCandidate: (id) => set((state) => {
    const candidates = state.candidates.filter((c) => c.id !== id);
    const interviews = state.interviews.filter((i) => i.candidateId !== id);
    localStorage.setItem('candidates', JSON.stringify(candidates));
    localStorage.setItem('interviews', JSON.stringify(interviews));
    return { candidates, interviews };
  }),

  setInterviews: (interviews) => {
    set({ interviews });
    localStorage.setItem('interviews', JSON.stringify(interviews));
  },

  addInterview: (interview) => set((state) => {
    const interviews = [...state.interviews, interview];
    localStorage.setItem('interviews', JSON.stringify(interviews));
    return { interviews };
  }),

  updateInterview: (interview) => set((state) => {
    const interviews = state.interviews.map((i) => 
      i.id === interview.id ? interview : i
    );
    localStorage.setItem('interviews', JSON.stringify(interviews));
    return { interviews };
  }),

  deleteInterview: (id) => set((state) => {
    const interviews = state.interviews.filter((i) => i.id !== id);
    localStorage.setItem('interviews', JSON.stringify(interviews));
    return { interviews };
  }),

  setAvailability: (availability) => {
    set({ availability });
    localStorage.setItem('availability', JSON.stringify(availability));
  },

  updateEmployeeAvailability: (employeeId, slots) => set((state) => {
    const availability = [
      ...state.availability.filter(a => a.employeeId !== employeeId),
      { employeeId, slots }
    ];
    localStorage.setItem('availability', JSON.stringify(availability));
    return { availability };
  })
}));