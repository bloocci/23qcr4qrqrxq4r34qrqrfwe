import { useForm } from 'react-hook-form';
import { X, Calendar, Clock, User, MessageSquare, ThumbsUp, ThumbsDown } from 'lucide-react';
import type { Interview, Candidate } from '../../types';

interface InterviewFormProps {
  onClose: () => void;
  onSubmit: (data: Omit<Interview, 'id'>) => void;
  onDelete?: (id: string) => void;
  selectedInterview?: Interview;
  candidates: Candidate[];
  employees: { id: string; firstName: string; lastName: string; role: { name: string } }[];
  initialDate?: Date;
  initialHour?: number;
}

const INTERVIEW_TYPES = [
  { value: 'screening', label: 'Initial Screening' },
  { value: 'technical', label: 'Technical Interview' },
  { value: 'cultural', label: 'Cultural Fit' },
  { value: 'final', label: 'Final Interview' }
];

export function InterviewForm({
  onClose,
  onSubmit,
  onDelete,
  selectedInterview,
  candidates,
  employees,
  initialDate,
  initialHour
}: InterviewFormProps) {
  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: selectedInterview || {
      startTime: initialDate ? new Date(initialDate.setHours(initialHour || 9, 0, 0, 0)).toISOString().slice(0, 16) : '',
      endTime: initialDate ? new Date(initialDate.setHours((initialHour || 9) + 1, 0, 0, 0)).toISOString().slice(0, 16) : '',
      type: 'screening',
      status: 'scheduled'
    }
  });

  const status = watch('status');

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">
            {selectedInterview ? 'Edit Interview' : 'Schedule Interview'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Candidate
              </label>
              <select
                {...register('candidateId', { required: 'Candidate is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="">Select candidate</option>
                {candidates.map(candidate => (
                  <option key={candidate.id} value={candidate.id}>
                    {candidate.firstName} {candidate.lastName} - {candidate.position}
                  </option>
                ))}
              </select>
              {errors.candidateId && (
                <p className="mt-1 text-xs text-red-600">{errors.candidateId.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Interviewer
              </label>
              <select
                {...register('interviewerId', { required: 'Interviewer is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="">Select interviewer</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>
                    {emp.firstName} {emp.lastName} - {emp.role.name}
                  </option>
                ))}
              </select>
              {errors.interviewerId && (
                <p className="mt-1 text-xs text-red-600">{errors.interviewerId.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Interview Type
              </label>
              <select
                {...register('type', { required: 'Interview type is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                {INTERVIEW_TYPES.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Status
              </label>
              <select
                {...register('status')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="scheduled">Scheduled</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="no-show">No Show</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Start Time
              </label>
              <input
                type="datetime-local"
                {...register('startTime', { required: 'Start time is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
              {errors.startTime && (
                <p className="mt-1 text-xs text-red-600">{errors.startTime.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                End Time
              </label>
              <input
                type="datetime-local"
                {...register('endTime', { required: 'End time is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
              {errors.endTime && (
                <p className="mt-1 text-xs text-red-600">{errors.endTime.message}</p>
              )}
            </div>
          </div>

          {status === 'completed' && (
            <div className="space-y-4 border-t pt-4">
              <h4 className="font-medium text-gray-900">Interview Feedback</h4>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Rating
                </label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  {...register('feedback.rating')}
                  className="mt-1 block w-32 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Strengths
                </label>
                <textarea
                  {...register('feedback.strengths')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Areas for Improvement
                </label>
                <textarea
                  {...register('feedback.weaknesses')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Recommendation
                </label>
                <select
                  {...register('feedback.recommendation')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                >
                  <option value="strong_yes">Strong Yes</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                  <option value="strong_no">Strong No</option>
                </select>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Notes
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              placeholder="Additional notes about the interview"
            />
          </div>

          <div className="flex justify-end space-x-3">
            {selectedInterview && onDelete && (
              <button
                type="button"
                onClick={() => onDelete(selectedInterview.id)}
                className="px-4 py-2 border border-red-300 text-red-700 rounded-md text-sm font-medium hover:bg-red-50"
              >
                Delete Interview
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              {selectedInterview ? 'Update Interview' : 'Schedule Interview'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}