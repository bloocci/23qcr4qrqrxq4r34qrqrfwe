import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { X, Building2, Shield } from 'lucide-react';
import type { Role } from '../../types';
import { cn } from '../../lib/utils';

interface AddRoleFormProps {
  onClose: () => void;
  onSubmit: (data: Omit<Role, 'id'>) => void;
}

export function AddRoleForm({ onClose, onSubmit }: AddRoleFormProps) {
  const [colorCode, setColorCode] = useState(generateRandomColor());
  const { register, handleSubmit, formState: { errors } } = useForm();

  function generateRandomColor() {
    const colors = [
      '#4F46E5', // Indigo
      '#10B981', // Emerald
      '#F59E0B', // Amber
      '#6366F1', // Indigo
      '#EC4899', // Pink
      '#8B5CF6', // Purple
      '#14B8A6', // Teal
      '#F97316', // Orange
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  const handleFormSubmit = (data: any) => {
    const roleData = {
      name: data.name,
      description: data.description,
      colorCode
    };
    onSubmit(roleData);
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <Building2 className="h-5 w-5 mr-2" />
            Add New Role
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(handleFormSubmit)} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Role Name
            </label>
            <input
              type="text"
              {...register('name', { required: 'Role name is required' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              placeholder="e.g., Front Desk Manager"
            />
            {errors.name && (
              <p className="mt-1 text-xs text-red-600">{errors.name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              {...register('description', { required: 'Description is required' })}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              placeholder="Describe the role's main purpose and responsibilities"
            />
            {errors.description && (
              <p className="mt-1 text-xs text-red-600">{errors.description.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Color Code
            </label>
            <div className="mt-1 flex items-center space-x-3">
              <div
                className="w-8 h-8 rounded-full border-2 border-gray-200"
                style={{ backgroundColor: colorCode }}
              />
              <button
                type="button"
                onClick={() => setColorCode(generateRandomColor())}
                className="px-3 py-1 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 rounded-md"
              >
                Generate New Color
              </button>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Add Role
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}