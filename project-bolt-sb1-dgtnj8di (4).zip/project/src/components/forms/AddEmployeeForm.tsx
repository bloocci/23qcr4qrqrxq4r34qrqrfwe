import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { 
  X, User, Mail, Phone, Calendar, Building2, Plus, Clock, Briefcase,
  MapPin, Globe, Shield
} from 'lucide-react';
import type { Employee, Role, RecurringAppointment } from '../../types';
import { cn } from '../../lib/utils';

interface AddEmployeeFormProps {
  roles: Role[];
  onClose: () => void;
  onSubmit: (data: Omit<Employee, 'id'>) => void;
  onAddRole: (role: Omit<Role, 'id'>) => void;
  initialData?: Employee;
  mode?: 'create' | 'edit';
}

export function AddEmployeeForm({ 
  roles, 
  onClose, 
  onSubmit, 
  onAddRole,
  initialData, 
  mode = 'create' 
}: AddEmployeeFormProps) {
  const [activeSection, setActiveSection] = useState('personal');
  const [showRecruiting, setShowRecruiting] = useState(initialData?.recurringAppointments?.some(a => a.type === 'recruiting') ?? false);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    defaultValues: initialData || {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      roleId: '',
      startDate: '',
      department: '',
      location: '2021 E Hennepin', // Default location
      schedule: {
        monday: { enabled: true, timeSlots: [] },
        tuesday: { enabled: true, timeSlots: [] },
        wednesday: { enabled: true, timeSlots: [] },
        thursday: { enabled: true, timeSlots: [] },
        friday: { enabled: true, timeSlots: [] },
        saturday: { enabled: false, timeSlots: [] },
        sunday: { enabled: false, timeSlots: [] }
      },
      recurringAppointments: []
    }
  });

  const sections = [
    { id: 'personal', label: 'Personal', icon: User },
    { id: 'role', label: 'Role & Schedule', icon: Building2 },
    { id: 'recruiting', label: 'Recruiting', icon: Briefcase }
  ];

  const handleFormSubmit = (data: any) => {
    const selectedRole = roles.find(role => role.id === data.roleId);
    if (!selectedRole) return;

    // Convert schedule data
    const schedule = {
      monday: { enabled: data.schedule.monday.enabled, timeSlots: [] },
      tuesday: { enabled: data.schedule.tuesday.enabled, timeSlots: [] },
      wednesday: { enabled: data.schedule.wednesday.enabled, timeSlots: [] },
      thursday: { enabled: data.schedule.thursday.enabled, timeSlots: [] },
      friday: { enabled: data.schedule.friday.enabled, timeSlots: [] },
      saturday: { enabled: data.schedule.saturday.enabled, timeSlots: [] },
      sunday: { enabled: data.schedule.sunday.enabled, timeSlots: [] }
    };

    // Add recruiting appointment if enabled
    const recurringAppointments: RecurringAppointment[] = [];
    if (showRecruiting && data.recruitingStartTime && data.recruitingEndTime) {
      recurringAppointments.push({
        id: Math.random().toString(36).substr(2, 9),
        title: 'Recruiting Hours',
        startTime: data.recruitingStartTime,
        endTime: data.recruitingEndTime,
        type: 'recruiting',
        repeatUntil: data.recruitingEndDate,
        daysOfWeek: {
          monday: data.recruitingDays?.monday || false,
          tuesday: data.recruitingDays?.tuesday || false,
          wednesday: data.recruitingDays?.wednesday || false,
          thursday: data.recruitingDays?.thursday || false,
          friday: data.recruitingDays?.friday || false,
          saturday: data.recruitingDays?.saturday || false,
          sunday: data.recruitingDays?.sunday || false
        }
      });
    }

    onSubmit({
      ...data,
      role: selectedRole,
      schedule,
      recurringAppointments
    });
  };

  return (
    <div className="fixed inset-0 bg-gray-900/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="relative bg-white w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-8 py-6 bg-white border-b border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-900">
            {mode === 'create' ? 'Add New Employee' : 'Edit Employee'}
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Navigation */}
        <div className="bg-gray-50 border-b border-gray-200">
          <nav className="flex px-8 space-x-8" aria-label="Tabs">
            {sections.map(section => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={cn(
                    "flex items-center py-4 px-1 border-b-2 text-sm font-medium transition-colors",
                    activeSection === section.id
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  )}
                >
                  <Icon className="h-5 w-5 mr-2" />
                  {section.label}
                </button>
              );
            })}
          </nav>
        </div>

        <form id="employee-form" onSubmit={handleSubmit(handleFormSubmit)} className="p-8 max-h-[calc(100vh-12rem)] overflow-y-auto">
          {/* Personal Information */}
          <div className={cn("space-y-6", activeSection !== 'personal' && "hidden")}>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  First Name
                </label>
                <input
                  type="text"
                  {...register('firstName', { required: 'First name is required' })}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter first name"
                />
                {errors.firstName && (
                  <p className="mt-1 text-sm text-red-600">{errors.firstName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Last Name
                </label>
                <input
                  type="text"
                  {...register('lastName', { required: 'Last name is required' })}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter last name"
                />
                {errors.lastName && (
                  <p className="mt-1 text-sm text-red-600">{errors.lastName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <div className="mt-1 relative rounded-lg shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    {...register('email', {
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Invalid email address"
                      }
                    })}
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="email@example.com"
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Phone
                </label>
                <div className="mt-1 relative rounded-lg shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="tel"
                    {...register('phone')}
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="(555) 555-5555"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Department
                </label>
                <div className="mt-1 relative rounded-lg shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Building2 className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    {...register('department')}
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="e.g. Engineering"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Location
                </label>
                <div className="mt-1 relative rounded-lg shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    {...register('location')}
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    defaultValue="2021 E Hennepin"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Role & Schedule */}
          <div className={cn("space-y-6", activeSection !== 'role' && "hidden")}>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Role
                </label>
                <div className="mt-1 flex rounded-lg shadow-sm">
                  <select
                    {...register('roleId', { required: 'Role is required' })}
                    className="flex-1 rounded-l-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="">Select a role</option>
                    {roles.map(role => (
                      <option key={role.id} value={role.id}>{role.name}</option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="relative -ml-px inline-flex items-center space-x-2 rounded-r-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <Plus className="h-4 w-4" />
                    <span>New Role</span>
                  </button>
                </div>
                {errors.roleId && (
                  <p className="mt-1 text-sm text-red-600">{errors.roleId.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Start Date
                </label>
                <div className="mt-1 relative rounded-lg shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="date"
                    {...register('startDate', { required: 'Start date is required' })}
                    className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                {errors.startDate && (
                  <p className="mt-1 text-sm text-red-600">{errors.startDate.message}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Working Days
              </label>
              <div className="grid grid-cols-7 gap-4">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                  const dayKey = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][index];
                  return (
                    <label key={day} className="flex flex-col items-center">
                      <span className="text-sm text-gray-600">{day}</span>
                      <input
                        type="checkbox"
                        {...register(`schedule.${dayKey}.enabled`)}
                        className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Recruiting Schedule */}
          <div className={cn("space-y-6", activeSection !== 'recruiting' && "hidden")}>
            <div className="flex items-center justify-between">
              <div className="flex items-center text-gray-900">
                <Briefcase className="h-5 w-5 mr-2" />
                <h3 className="text-lg font-medium">Recruiting Schedule</h3>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={showRecruiting}
                  onChange={(e) => setShowRecruiting(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-600">Available for recruiting</span>
              </div>
            </div>

            {showRecruiting && (
              <div className="space-y-6 bg-gray-50 p-6 rounded-xl border border-gray-200">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Start Time
                    </label>
                    <div className="mt-1 relative rounded-lg shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="time"
                        {...register('recruitingStartTime')}
                        className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      End Time
                    </label>
                    <div className="mt-1 relative rounded-lg shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="time"
                        {...register('recruitingEndTime')}
                        className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Schedule End Date
                    </label>
                    <div className="mt-1 relative rounded-lg shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="date"
                        {...register('recruitingEndDate')}
                        className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Available Days for Recruiting
                  </label>
                  <div className="grid grid-cols-7 gap-4">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                      const dayKey = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][index];
                      return (
                        <label key={day} className="flex flex-col items-center">
                          <span className="text-sm text-gray-600">{day}</span>
                          <input
                            type="checkbox"
                            {...register(`recruitingDays.${dayKey}`)}
                            className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                        </label>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </form>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 px-8 py-4 flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500">
            <Shield className="h-4 w-4 mr-1" />
            All information is securely stored
          </div>
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              form="employee-form"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {mode === 'create' ? 'Add Employee' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}