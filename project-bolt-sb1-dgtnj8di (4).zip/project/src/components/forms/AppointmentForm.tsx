import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { X, Mail, Phone, Calendar, Clock, User, Briefcase, Calendar as CalendarIcon } from 'lucide-react';
import type { Appointment, AppointmentType, Employee } from '../../types';
import { format, addDays } from 'date-fns';

interface AppointmentFormProps {
  onClose: () => void;
  onSubmit: (data: any) => void;
  onDelete?: (id: string) => void;
  selectedAppointment: Appointment | null;
  initialDate?: Date;
  initialHour?: number;
  employees: Employee[];
  roles: { id: string; name: string }[];
}

const APPOINTMENT_TYPES: { value: AppointmentType; label: string }[] = [
  { value: 'screening', label: 'Initial Screening' },
  { value: 'interview', label: 'Interview' },
  { value: 'technical', label: 'Technical Interview' },
  { value: 'followup', label: 'Follow-up Interview' }
];

export function AppointmentForm({
  onClose,
  onSubmit,
  onDelete,
  selectedAppointment,
  initialDate,
  initialHour,
  employees,
  roles
}: AppointmentFormProps) {
  const [isRecruiting, setIsRecruiting] = useState(selectedAppointment?.type === 'interview' || selectedAppointment?.type === 'screening');
  const [selectedDates, setSelectedDates] = useState<Date[]>(
    selectedAppointment ? [new Date(selectedAppointment.startTime)] : initialDate ? [initialDate] : []
  );

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    defaultValues: selectedAppointment || {
      startTime: initialDate ? new Date(initialDate.setHours(initialHour || 9, 0, 0, 0)).toISOString().slice(0, 16) : '',
      endTime: initialDate ? new Date(initialDate.setHours((initialHour || 9) + 1, 0, 0, 0)).toISOString().slice(0, 16) : '',
      type: 'interview',
      status: 'scheduled'
    }
  });

  const appointmentType = watch('type');

  // Update isRecruiting when appointment type changes
  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const type = e.target.value as AppointmentType;
    setIsRecruiting(type === 'interview' || type === 'screening');
    setValue('type', type);
  };

  const handleDateSelect = (date: Date) => {
    if (selectedDates.some(d => d.getTime() === date.getTime())) {
      setSelectedDates(selectedDates.filter(d => d.getTime() !== date.getTime()));
    } else {
      setSelectedDates([...selectedDates, date]);
    }
  };

  const handleFormSubmit = (data: any) => {
    // If it's a recruiting appointment and multiple dates are selected,
    // create an appointment for each date
    if (isRecruiting && selectedDates.length > 0) {
      const appointments = selectedDates.map(date => ({
        ...data,
        startTime: new Date(date.setHours(
          new Date(data.startTime).getHours(),
          new Date(data.startTime).getMinutes()
        )).toISOString(),
        endTime: new Date(date.setHours(
          new Date(data.endTime).getHours(),
          new Date(data.endTime).getMinutes()
        )).toISOString(),
      }));
      onSubmit(appointments);
    } else {
      onSubmit(data);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">
            {selectedAppointment ? 'Edit Appointment' : 'Schedule Appointment'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(handleFormSubmit)} className="p-6 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Appointment Type
              </label>
              <select
                {...register('type', { required: 'Appointment type is required' })}
                onChange={handleTypeChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                {APPOINTMENT_TYPES.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
              {errors.type && (
                <p className="mt-1 text-xs text-red-600">{errors.type.message}</p>
              )}
            </div>

            {isRecruiting && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Interview Dates
                </label>
                <div className="grid grid-cols-7 gap-2">
                  {Array.from({ length: 14 }, (_, i) => {
                    const date = addDays(new Date(), i);
                    const isSelected = selectedDates.some(d => d.getTime() === date.getTime());
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleDateSelect(date)}
                        className={`p-2 text-sm rounded-md border ${
                          isSelected
                            ? 'bg-blue-50 border-blue-500 text-blue-700'
                            : 'border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="text-xs font-medium">{format(date, 'EEE')}</div>
                        <div className="font-bold">{format(date, 'd')}</div>
                      </button>
                    );
                  })}
                </div>
                {selectedDates.length === 0 && (
                  <p className="mt-1 text-xs text-red-600">Please select at least one date</p>
                )}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">
                {isRecruiting ? 'Candidate Name' : 'Name'}
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  {...register('candidateName', { required: 'Name is required' })}
                  className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>
              {errors.candidateName && (
                <p className="mt-1 text-xs text-red-600">{errors.candidateName.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    {...register('email', { 
                      required: 'Email is required',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Invalid email address"
                      }
                    })}
                    className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Phone
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="tel"
                    {...register('phone')}
                    className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    placeholder="(555) 555-5555"
                  />
                </div>
              </div>
            </div>

            {isRecruiting && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Position
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Briefcase className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    {...register('position', { required: 'Position is required' })}
                    className="block w-full pl-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    <option value="">Select position</option>
                    {roles.map(role => (
                      <option key={role.id} value={role.name}>{role.name}</option>
                    ))}
                  </select>
                </div>
                {errors.position && (
                  <p className="mt-1 text-xs text-red-600">{errors.position.message}</p>
                )}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700">
                {isRecruiting ? 'Interviewer' : 'Employee'}
              </label>
              <select
                {...register('interviewerId', { required: `${isRecruiting ? 'Interviewer' : 'Employee'} is required` })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              >
                <option value="">Select {isRecruiting ? 'interviewer' : 'employee'}</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>
                    {emp.firstName} {emp.lastName} - {emp.role.name}
                  </option>
                ))}
              </select>
              {errors.interviewerId && (
                <p className="mt-1 text-xs text-red-600">{errors.interviewerId.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Start Time
                </label>
                <input
                  type="time"
                  {...register('startTime', { required: 'Start time is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
                {errors.startTime && (
                  <p className="mt-1 text-xs text-red-600">{errors.startTime.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  End Time
                </label>
                <input
                  type="time"
                  {...register('endTime', { required: 'End time is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
                {errors.endTime && (
                  <p className="mt-1 text-xs text-red-600">{errors.endTime.message}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Notes
              </label>
              <textarea
                {...register('notes')}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                placeholder={isRecruiting ? "Additional notes about the candidate or interview" : "Additional notes about the appointment"}
              />
            </div>

            {selectedAppointment && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Status
                </label>
                <select
                  {...register('status')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                >
                  <option value="scheduled">Scheduled</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                  <option value="no-show">No Show</option>
                </select>
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-3">
            {selectedAppointment && onDelete && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this appointment?')) {
                    onDelete(selectedAppointment.id);
                    onClose();
                  }
                }}
                className="px-4 py-2 border border-red-300 text-red-700 rounded-md text-sm font-medium hover:bg-red-50"
              >
                Delete Appointment
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              {selectedAppointment ? 'Update Appointment' : 'Schedule Appointment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}