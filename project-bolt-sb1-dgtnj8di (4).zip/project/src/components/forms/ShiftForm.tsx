import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { X, Calendar as CalendarIcon, Clock, Trash2, AlertCircle, Calendar } from 'lucide-react';
import type { Shift, Employee } from '../../types';
import { format, addDays, parseISO } from 'date-fns';
import { DeleteConfirmationDialog } from '../ui/DeleteConfirmationDialog';
import { useScheduleStore } from '../../store/scheduleStore';

interface ShiftFormProps {
  onClose: () => void;
  onSubmit: (data: Shift, updateAll?: boolean) => void;
  onDelete: (id: string, deleteRecurring?: boolean) => void;
  selectedShift: Shift | null;
  employees: Employee[];
  roles: { id: string; name: string }[];
  initialDate?: Date;
  initialHour?: number;
}

export function ShiftForm({
  onClose,
  onSubmit,
  onDelete,
  selectedShift,
  employees,
  roles,
  initialDate = new Date(),
  initialHour = 9
}: ShiftFormProps) {
  const { lastSettings } = useScheduleStore();
  
  const [isRecurring, setIsRecurring] = useState(() => {
    if (selectedShift) return !!selectedShift.recurringId;
    return lastSettings.isRecurring ?? false;
  });

  const [selectedDays, setSelectedDays] = useState<string[]>(() => {
    if (selectedShift?.recurringDays) return selectedShift.recurringDays.split(',');
    return lastSettings.recurringDays || [];
  });

  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showUpdateDialog, setShowUpdateDialog] = useState(false);
  const [formData, setFormData] = useState<any>(null);

  // Calculate initial times based on last settings or defaults
  const getInitialTimes = () => {
    const startTime = new Date(initialDate);
    startTime.setHours(initialHour, 0, 0, 0);

    const endTime = new Date(startTime);
    if (lastSettings.shiftDuration && !selectedShift) {
      const hours = Math.floor(lastSettings.shiftDuration);
      const minutes = Math.round((lastSettings.shiftDuration - hours) * 60);
      endTime.setHours(initialHour + hours, minutes);
    } else {
      endTime.setHours(initialHour + 1);
    }

    return {
      startTime: format(startTime, "yyyy-MM-dd'T'HH:mm"),
      endTime: format(endTime, "yyyy-MM-dd'T'HH:mm")
    };
  };

  const initialTimes = getInitialTimes();

  // Initialize form with either selected shift or last settings
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    defaultValues: selectedShift ? {
      ...selectedShift
    } : {
      id: '',
      employeeId: lastSettings.employeeId || '',
      startTime: initialTimes.startTime,
      endTime: initialTimes.endTime,
      title: lastSettings.title || '',
      type: 'regular',
      notes: lastSettings.notes || '',
      recurringId: '',
      recurringDays: '',
      recurringUntil: format(
        addDays(initialDate, lastSettings.recurringDuration || 30), 
        'yyyy-MM-dd'
      )
    }
  });

  // Update recurring days when they change
  useEffect(() => {
    if (isRecurring) {
      setValue('recurringDays', selectedDays.join(','));
    } else {
      setValue('recurringDays', '');
    }
  }, [isRecurring, selectedDays, setValue]);

  const handleFormSubmit = (data: any) => {
    if (selectedShift?.recurringId) {
      setFormData(data);
      setShowUpdateDialog(true);
    } else {
      submitForm(data, false);
    }
  };

  const submitForm = (data: any, updateAll: boolean = false) => {
    const formData: Shift = {
      ...data,
      id: selectedShift?.id || Math.random().toString(36).substr(2, 9)
    };

    if (isRecurring) {
      formData.recurringId = selectedShift?.recurringId || Math.random().toString(36).substr(2, 9);
      formData.recurringDays = selectedDays.join(',');
      
      if (!formData.recurringDays) {
        alert('Please select at least one day for recurring appointments');
        return;
      }

      const startDate = formData.startTime.split('T')[0];
      
      if (formData.recurringUntil < startDate) {
        alert('Recurring end date must be after the start date');
        return;
      }
    } else {
      formData.recurringId = undefined;
      formData.recurringDays = undefined;
      formData.recurringUntil = undefined;
    }

    onSubmit(formData, updateAll);
    onClose();
  };

  const handleDeleteClick = () => {
    if (!selectedShift) return;
    setShowDeleteDialog(true);
  };

  return (
    <>
      <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">
              {selectedShift ? 'Edit Appointment' : 'Schedule Appointment'}
            </h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit(handleFormSubmit)} className="p-6 space-y-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Employee
                </label>
                <select
                  {...register('employeeId', { required: 'Employee is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                >
                  <option value="">Select employee</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.firstName} {emp.lastName} - {emp.role.name}
                    </option>
                  ))}
                </select>
                {errors.employeeId && (
                  <p className="mt-1 text-xs text-red-600">{errors.employeeId.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Shift Title
                </label>
                <input
                  type="text"
                  {...register('title')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  placeholder="e.g. Morning Shift"
                />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Start Time
                  </label>
                  <input
                    type="datetime-local"
                    {...register('startTime', { required: 'Start time is required' })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                  {errors.startTime && (
                    <p className="mt-1 text-xs text-red-600">{errors.startTime.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    End Time
                  </label>
                  <input
                    type="datetime-local"
                    {...register('endTime', { required: 'End time is required' })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                  {errors.endTime && (
                    <p className="mt-1 text-xs text-red-600">{errors.endTime.message}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="recurring"
                  checked={isRecurring}
                  onChange={(e) => setIsRecurring(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="recurring" className="text-sm font-medium text-gray-700 flex items-center">
                  <CalendarIcon className="h-4 w-4 mr-1" />
                  Recurring Appointment
                </label>
              </div>

              {isRecurring && (
                <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Repeat on
                    </label>
                    <div className="grid grid-cols-7 gap-2">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            setSelectedDays(prev =>
                              prev.includes(day)
                                ? prev.filter(d => d !== day)
                                : [...prev, day]
                            );
                          }}
                          className={`p-2 text-sm rounded-md border ${
                            selectedDays.includes(day)
                              ? "bg-blue-50 border-blue-500 text-blue-700"
                              : "border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          {day}
                        </button>
                      ))}
                    </div>
                    {selectedDays.length === 0 && (
                      <p className="mt-1 text-xs text-red-500">
                        Please select at least one day
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Repeat Until
                    </label>
                    <input
                      type="date"
                      {...register('recurringUntil')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      min={watch('startTime')?.split('T')?.[0]}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Notes
                </label>
                <textarea
                  {...register('notes')}
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  placeholder="Additional notes about the appointment"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              {selectedShift && (
                <button
                  type="button"
                  onClick={handleDeleteClick}
                  className="inline-flex items-center px-4 py-2 border border-red-300 text-red-700 rounded-md text-sm font-medium hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete {selectedShift.recurringId ? 'Appointment(s)' : 'Appointment'}
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                {selectedShift ? 'Update Appointment' : 'Schedule Appointment'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <DeleteConfirmationDialog
        isOpen={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        onConfirm={(deleteRecurring) => {
          if (!selectedShift) return;
          onDelete(selectedShift.id, deleteRecurring);
          onClose();
        }}
        title="Delete Appointment"
        message={selectedShift?.recurringId 
          ? "How would you like to handle this recurring appointment?"
          : "Are you sure you want to delete this appointment?"}
        showDeleteRelated={!!selectedShift?.recurringId}
        deleteRelatedMessage="Would you like to delete this and all future occurrences of this recurring appointment?"
        itemName={selectedShift?.title || 'Untitled Appointment'}
      />

      <DeleteConfirmationDialog
        isOpen={showUpdateDialog}
        onClose={() => setShowUpdateDialog(false)}
        onConfirm={(updateAll) => {
          if (!formData) return;
          submitForm(formData, updateAll);
        }}
        title="Update Recurring Appointment"
        message="How would you like to update this recurring appointment?"
        showDeleteRelated={true}
        deleteRelatedMessage="Would you like to update this and all future occurrences of this recurring appointment?"
        itemName={selectedShift?.title || 'Untitled Appointment'}
        confirmLabel="Update Only This"
        confirmAllLabel="Update All Future"
      />
    </>
  );
}