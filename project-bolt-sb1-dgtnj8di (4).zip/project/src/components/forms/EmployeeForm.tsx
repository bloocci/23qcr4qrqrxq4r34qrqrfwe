// Add recurring appointments section to form
const sections = [
  { id: 'personal', label: 'Personal', icon: User },
  { id: 'role', label: 'Role & Schedule', icon: Building2 },
  { id: 'recruiting', label: 'Recruiting', icon: Briefcase }
];

// Add to form state
const [showRecruiting, setShowRecruiting] = useState(initialData?.recurringAppointments?.some(a => a.type === 'recruiting') ?? false);

// Add to form submission
const handleFormSubmit = (data: any) => {
  const selectedRole = roles.find(role => role.id === data.roleId);
  if (!selectedRole) return;

  const schedule = {
    monday: { enabled: data.schedule.monday.enabled, timeSlots: [] },
    tuesday: { enabled: data.schedule.tuesday.enabled, timeSlots: [] },
    wednesday: { enabled: data.schedule.wednesday.enabled, timeSlots: [] },
    thursday: { enabled: data.schedule.thursday.enabled, timeSlots: [] },
    friday: { enabled: data.schedule.friday.enabled, timeSlots: [] },
    saturday: { enabled: data.schedule.saturday.enabled, timeSlots: [] },
    sunday: { enabled: data.schedule.sunday.enabled, timeSlots: [] }
  };

  // Add recruiting appointment if enabled
  const recurringAppointments: RecurringAppointment[] = [];
  if (showRecruiting && data.recruitingStartTime && data.recruitingEndTime) {
    recurringAppointments.push({
      id: Math.random().toString(36).substr(2, 9),
      title: 'Recruiting Hours',
      startTime: data.recruitingStartTime,
      endTime: data.recruitingEndTime,
      type: 'recruiting',
      repeatUntil: data.recruitingEndDate,
      daysOfWeek: {
        monday: data.recruitingDays?.monday || false,
        tuesday: data.recruitingDays?.tuesday || false,
        wednesday: data.recruitingDays?.wednesday || false,
        thursday: data.recruitingDays?.thursday || false,
        friday: data.recruitingDays?.friday || false,
        saturday: data.recruitingDays?.saturday || false,
        sunday: data.recruitingDays?.sunday || false
      }
    });
  }

  onSubmit({
    ...data,
    role: selectedRole,
    schedule,
    recurringAppointments
  });
};

// Add recruiting section to form JSX
{activeSection === 'recruiting' && (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <div className="flex items-center text-gray-900">
        <Briefcase className="h-5 w-5 mr-2" />
        <h3 className="text-lg font-medium">Recruiting Schedule</h3>
      </div>
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={showRecruiting}
          onChange={(e) => setShowRecruiting(e.target.checked)}
          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
        />
        <span className="ml-2 text-sm text-gray-600">Available for recruiting</span>
      </div>
    </div>

    {showRecruiting && (
      <div className="space-y-6 bg-gray-50 p-6 rounded-xl border border-gray-200">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Start Time
            </label>
            <div className="mt-1 relative rounded-lg shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="time"
                {...register('recruitingStartTime')}
                className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              End Time
            </label>
            <div className="mt-1 relative rounded-lg shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="time"
                {...register('recruitingEndTime')}
                className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Schedule End Date
            </label>
            <div className="mt-1 relative rounded-lg shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="date"
                {...register('recruitingEndDate')}
                className="block w-full pl-10 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Available Days for Recruiting
          </label>
          <div className="grid grid-cols-7 gap-4">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
              const dayKey = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][index];
              return (
                <label key={day} className="flex flex-col items-center">
                  <span className="text-sm text-gray-600">{day}</span>
                  <input
                    type="checkbox"
                    {...register(`recruitingDays.${dayKey}`)}
                    className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </label>
              );
            })}
          </div>
        </div>
      </div>
    )}
  </div>
)}