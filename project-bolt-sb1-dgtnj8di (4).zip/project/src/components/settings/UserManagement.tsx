import { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { 
  UserPlus, UserCheck, UserX, Clock, AlertCircle,
  History, Shield, User, Mail, Calendar
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface PendingUser {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  created_at: string;
}

interface ApprovalHistory {
  history_id: string;
  user_id: string;
  email: string;
  first_name: string;
  last_name: string;
  approved_by_first_name: string;
  approved_by_last_name: string;
  status: string;
  reason: string | null;
  created_at: string;
}

export function UserManagement() {
  const { user } = useAuthStore();
  const isAdmin = user?.role === 'admin';
  
  // For local version, we'll use empty arrays since we don't need user management
  const [pendingUsers] = useState<PendingUser[]>([]);
  const [approvalHistory] = useState<ApprovalHistory[]>([]);

  if (!isAdmin) {
    return (
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              Only administrators can access user management features.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Pending Users */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-5 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <Clock className="h-5 w-5 text-orange-500 mr-2" />
            Pending Approvals
          </h3>
        </div>
        <div className="divide-y divide-gray-200">
          {pendingUsers.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No pending approvals
            </div>
          ) : (
            pendingUsers.map((pendingUser) => (
              <div key={pendingUser.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <User className="h-10 w-10 text-gray-400" />
                    </div>
                    <div className="ml-4">
                      <h4 className="text-lg font-medium text-gray-900">
                        {pendingUser.first_name} {pendingUser.last_name}
                      </h4>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <Mail className="flex-shrink-0 mr-1.5 h-4 w-4" />
                        {pendingUser.email}
                      </div>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <Shield className="flex-shrink-0 mr-1.5 h-4 w-4" />
                        Role: {pendingUser.role}
                      </div>
                      <div className="mt-1 flex items-center text-sm text-gray-500">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4" />
                        Registered: {format(new Date(pendingUser.created_at), 'PPp')}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    <button
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                    >
                      <UserCheck className="h-4 w-4 mr-2" />
                      Approve
                    </button>
                    <button
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
                    >
                      <UserX className="h-4 w-4 mr-2" />
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Approval History */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-5 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <History className="h-5 w-5 text-blue-500 mr-2" />
            Approval History
          </h3>
        </div>
        <div className="divide-y divide-gray-200">
          {approvalHistory.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No approval history
            </div>
          ) : (
            approvalHistory.map((history) => (
              <div key={history.history_id} className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    {history.status === 'approved' ? (
                      <UserCheck className="h-8 w-8 text-green-500" />
                    ) : history.status === 'rejected' ? (
                      <UserX className="h-8 w-8 text-red-500" />
                    ) : (
                      <UserPlus className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium text-gray-900">
                      {history.first_name} {history.last_name}
                    </h4>
                    <div className="mt-1 text-sm text-gray-500">
                      <span className="font-medium">Status:</span>{' '}
                      <span className={`capitalize ${
                        history.status === 'approved' ? 'text-green-600' :
                        history.status === 'rejected' ? 'text-red-600' :
                        'text-gray-600'
                      }`}>
                        {history.status}
                      </span>
                    </div>
                    <div className="mt-1 text-sm text-gray-500">
                      <span className="font-medium">By:</span>{' '}
                      {history.approved_by_first_name} {history.approved_by_last_name}
                    </div>
                    <div className="mt-1 text-sm text-gray-500">
                      <span className="font-medium">Date:</span>{' '}
                      {format(new Date(history.created_at), 'PPp')}
                    </div>
                    {history.reason && (
                      <div className="mt-1 text-sm text-gray-500">
                        <span className="font-medium">Reason:</span>{' '}
                        {history.reason}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}