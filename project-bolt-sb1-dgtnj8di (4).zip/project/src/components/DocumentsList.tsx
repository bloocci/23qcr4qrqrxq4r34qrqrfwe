import { File, Download, Trash2, Calendar } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: string;
  uploadDate: string;
  size: string;
}

interface DocumentsListProps {
  documents: Document[];
  onDownload: (documentId: string) => void;
  onDelete: (documentId: string) => void;
}

export function DocumentsList({ documents, onDownload, onDelete }: DocumentsListProps) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">
          Documents
        </h3>
      </div>
      <div className="divide-y divide-gray-200">
        {documents.map((doc) => (
          <div key={doc.id} className="p-4 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <File className="h-5 w-5 text-gray-400" />
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-gray-900">
                    {doc.name}
                  </h4>
                  <div className="flex items-center mt-1 text-xs text-gray-500 space-x-4">
                    <span>{doc.type}</span>
                    <span>{doc.size}</span>
                    <span className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {doc.uploadDate}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onDownload(doc.id)}
                  className="p-1 text-gray-400 hover:text-gray-500"
                >
                  <Download className="h-4 w-4" />
                </button>
                <button
                  onClick={() => onDelete(doc.id)}
                  className="p-1 text-gray-400 hover:text-red-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}