import { Fragment } from 'react';
import { cn } from '@/lib/utils';

interface MenuItem {
  label: string;
  onClick?: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
  variant?: 'default' | 'danger';
  divider?: boolean;
}

interface MenuProps {
  items: MenuItem[];
  className?: string;
}

export function Menu({
  items,
  className
}: MenuProps) {
  return (
    <div className={cn('py-1', className)}>
      {items.map((item, index) => (
        <Fragment key={index}>
          {item.divider ? (
            <div className="my-1 h-px bg-gray-200" />
          ) : (
            <button
              onClick={item.onClick}
              disabled={item.disabled}
              className={cn(
                'group flex w-full items-center px-4 py-2 text-sm',
                item.disabled
                  ? 'cursor-not-allowed text-gray-400'
                  : item.variant === 'danger'
                  ? 'text-red-700 hover:bg-red-50'
                  : 'text-gray-700 hover:bg-gray-50',
                'focus:outline-none'
              )}
            >
              {item.icon && (
                <span className={cn(
                  'mr-3 h-5 w-5',
                  item.variant === 'danger' ? 'text-red-400' : 'text-gray-400 group-hover:text-gray-500'
                )}>
                  {item.icon}
                </span>
              )}
              {item.label}
            </button>
          )}
        </Fragment>
      )}
    </div>
  );
}