import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
  className?: string;
}

export function Checkbox({
  checked,
  onChange,
  label,
  disabled,
  className
}: CheckboxProps) {
  return (
    <label className={cn(
      'inline-flex items-center',
      disabled && 'opacity-50 cursor-not-allowed',
      className
    )}>
      <div className="relative flex items-center">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          disabled={disabled}
          className="sr-only"
        />
        <div
          className={cn(
            'h-5 w-5 rounded border transition-colors',
            checked
              ? 'bg-blue-600 border-blue-600'
              : 'border-gray-300 bg-white',
            !disabled && 'hover:border-blue-500'
          )}
        >
          {checked && (
            <Check className="h-4 w-4 text-white" />
          )}
        </div>
        {label && (
          <span className="ml-2 text-sm text-gray-900">{label}</span>
        )}
      </div>
    </label>
  );
}