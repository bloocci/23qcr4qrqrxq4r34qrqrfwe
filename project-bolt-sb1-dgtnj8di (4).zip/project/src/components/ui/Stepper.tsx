import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Step {
  id: string;
  title: string;
  description?: string;
}

interface StepperProps {
  steps: Step[];
  currentStep: string;
  completedSteps?: string[];
  orientation?: 'horizontal' | 'vertical';
  className?: string;
}

export function Stepper({
  steps,
  currentStep,
  completedSteps = [],
  orientation = 'horizontal',
  className
}: StepperProps) {
  return (
    <div
      className={cn(
        orientation === 'horizontal' ? 'flex items-center' : 'flex flex-col space-y-4',
        className
      )}
    >
      {steps.map((step, index) => {
        const isCompleted = completedSteps.includes(step.id);
        const isCurrent = currentStep === step.id;
        const isLast = index === steps.length - 1;

        return (
          <div
            key={step.id}
            className={cn(
              'flex',
              orientation === 'horizontal' ? 'items-center' : '',
              !isLast && orientation === 'horizontal' ? 'flex-1' : ''
            )}
          >
            <div className="flex items-center">
              <div
                className={cn(
                  'relative flex h-8 w-8 items-center justify-center rounded-full border-2',
                  isCompleted
                    ? 'border-blue-600 bg-blue-600'
                    : isCurrent
                    ? 'border-blue-600'
                    : 'border-gray-300'
                )}
              >
                {isCompleted ? (
                  <Check className="h-5 w-5 text-white" />
                ) : (
                  <span
                    className={cn(
                      'text-sm font-medium',
                      isCurrent ? 'text-blue-600' : 'text-gray-500'
                    )}
                  >
                    {index + 1}
                  </span>
                )}
              </div>
              <div className="ml-4">
                <p
                  className={cn(
                    'text-sm font-medium',
                    isCurrent ? 'text-blue-600' : 'text-gray-900'
                  )}
                >
                  {step.title}
                </p>
                {step.description && (
                  <p className="text-sm text-gray-500">{step.description}</p>
                )}
              </div>
            </div>
            {!isLast && (
              <div
                className={cn(
                  orientation === 'horizontal'
                    ? 'ml-4 h-0.5 flex-1'
                    : 'ml-3.5 mt-3 h-full w-0.5',
                  isCompleted ? 'bg-blue-600' : 'bg-gray-200'
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}