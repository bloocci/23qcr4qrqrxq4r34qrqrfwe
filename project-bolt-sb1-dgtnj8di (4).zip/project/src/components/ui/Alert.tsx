import { cn } from '@/lib/utils';
import { AlertCircle, CheckCircle, Info, X } from 'lucide-react';

interface AlertProps {
  title?: string;
  children: React.ReactNode;
  variant?: 'info' | 'success' | 'warning' | 'error';
  onClose?: () => void;
  className?: string;
}

export function Alert({
  title,
  children,
  variant = 'info',
  onClose,
  className
}: AlertProps) {
  const variants = {
    info: {
      container: 'bg-blue-50 border-blue-200',
      icon: <Info className="h-5 w-5 text-blue-400" />,
      title: 'text-blue-800',
      content: 'text-blue-700'
    },
    success: {
      container: 'bg-green-50 border-green-200',
      icon: <CheckCircle className="h-5 w-5 text-green-400" />,
      title: 'text-green-800',
      content: 'text-green-700'
    },
    warning: {
      container: 'bg-yellow-50 border-yellow-200',
      icon: <AlertCircle className="h-5 w-5 text-yellow-400" />,
      title: 'text-yellow-800',
      content: 'text-yellow-700'
    },
    error: {
      container: 'bg-red-50 border-red-200',
      icon: <AlertCircle className="h-5 w-5 text-red-400" />,
      title: 'text-red-800',
      content: 'text-red-700'
    }
  };

  return (
    <div
      className={cn(
        'rounded-md border p-4',
        variants[variant].container,
        className
      )}
    >
      <div className="flex">
        <div className="flex-shrink-0">
          {variants[variant].icon}
        </div>
        <div className="ml-3 flex-1">
          {title && (
            <h3 className={cn(
              'text-sm font-medium',
              variants[variant].title
            )}>
              {title}
            </h3>
          )}
          <div className={cn(
            'text-sm',
            title ? 'mt-2' : '',
            variants[variant].content
          )}>
            {children}
          </div>
        </div>
        {onClose && (
          <div className="ml-auto pl-3">
            <button
              type="button"
              onClick={onClose}
              className={cn(
                'inline-flex rounded-md p-1.5',
                variants[variant].content,
                'hover:bg-white focus:outline-none focus:ring-2 focus:ring-offset-2',
                `focus:ring-${variant === 'info' ? 'blue' : variant}-500`
              )}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}