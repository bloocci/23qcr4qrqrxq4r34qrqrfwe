import { cn } from '@/lib/utils';
import { User } from 'lucide-react';

interface AvatarProps {
  src?: string;
  alt?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  fallback?: string;
}

export function Avatar({
  src,
  alt,
  size = 'md',
  className,
  fallback
}: AvatarProps) {
  const sizes = {
    sm: 'h-8 w-8',
    md: 'h-10 w-10',
    lg: 'h-12 w-12'
  };

  if (!src && !fallback) {
    return (
      <div className={cn(
        'relative inline-flex items-center justify-center rounded-full bg-gray-100',
        sizes[size],
        className
      )}>
        <User className="h-1/2 w-1/2 text-gray-500" />
      </div>
    );
  }

  if (!src && fallback) {
    return (
      <div className={cn(
        'relative inline-flex items-center justify-center rounded-full bg-blue-100 text-blue-600 font-medium',
        sizes[size],
        className
      )}>
        {fallback.slice(0, 2).toUpperCase()}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={cn(
        'rounded-full object-cover',
        sizes[size],
        className
      )}
    />
  );
}