import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'light';
  className?: string;
}

export function Spinner({
  size = 'md',
  variant = 'default',
  className
}: SpinnerProps) {
  const sizes = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  };

  const variants = {
    default: 'text-gray-900',
    light: 'text-white'
  };

  return (
    <Loader2 
      className={cn(
        'animate-spin',
        sizes[size],
        variants[variant],
        className
      )}
    />
  );
}