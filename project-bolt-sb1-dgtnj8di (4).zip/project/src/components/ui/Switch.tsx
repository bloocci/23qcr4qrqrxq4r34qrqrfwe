import { cn } from '@/lib/utils';

interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function Switch({
  checked,
  onChange,
  label,
  disabled,
  size = 'md',
  className
}: SwitchProps) {
  const sizes = {
    sm: {
      switch: 'h-4 w-7',
      thumb: 'h-3 w-3',
      translate: 'translate-x-3'
    },
    md: {
      switch: 'h-6 w-11',
      thumb: 'h-5 w-5',
      translate: 'translate-x-5'
    },
    lg: {
      switch: 'h-8 w-14',
      thumb: 'h-7 w-7',
      translate: 'translate-x-6'
    }
  };

  return (
    <label className={cn(
      'relative inline-flex items-center',
      disabled && 'opacity-50 cursor-not-allowed',
      className
    )}>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        disabled={disabled}
        className="sr-only"
      />
      <div
        className={cn(
          'relative inline-flex flex-shrink-0 rounded-full cursor-pointer transition-colors ease-in-out duration-200',
          checked ? 'bg-blue-600' : 'bg-gray-200',
          sizes[size].switch
        )}
      >
        <span
          className={cn(
            'inline-block rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200',
            sizes[size].thumb,
            checked ? sizes[size].translate : 'translate-x-0.5'
          )}
        />
      </div>
      {label && (
        <span className="ml-3 text-sm font-medium text-gray-900">
          {label}
        </span>
      )}
    </label>
  );
}