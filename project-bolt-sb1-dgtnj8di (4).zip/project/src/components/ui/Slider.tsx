import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface SliderProps {
  min?: number;
  max?: number;
  step?: number;
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
  className?: string;
}

export function Slider({
  min = 0,
  max = 100,
  step = 1,
  value,
  onChange,
  disabled,
  className
}: SliderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);

  const percentage = ((value - min) / (max - min)) * 100;

  const handleMove = (clientX: number) => {
    if (disabled || !sliderRef.current) return;

    const rect = sliderRef.current.getBoundingClientRect();
    const width = rect.width;
    const left = rect.left;
    const newPercentage = Math.max(0, Math.min(100, ((clientX - left) / width) * 100));
    const newValue = Math.round((newPercentage * (max - min)) / 100 / step) * step + min;
    onChange(newValue);
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => handleMove(e.clientX);
    const handleMouseUp = () => setIsDragging(false);

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  return (
    <div
      ref={sliderRef}
      className={cn(
        'relative h-5 w-full',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
    >
      <div className="absolute h-1 top-2 w-full rounded-full bg-gray-200">
        <div
          className="absolute h-full rounded-full bg-blue-600"
          style={{ width: `${percentage}%` }}
        />
        <div
          className={cn(
            'absolute h-4 w-4 -top-1.5 rounded-full bg-white border-2 border-blue-600 transform -translate-x-1/2 transition-shadow',
            !disabled && 'cursor-grab hover:shadow-md active:cursor-grabbing'
          )}
          style={{ left: `${percentage}%` }}
          onMouseDown={() => !disabled && setIsDragging(true)}
        />
      </div>
    </div>
  );
}