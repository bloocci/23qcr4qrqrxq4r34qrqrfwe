import { cn } from '@/lib/utils';

interface Tab {
  id: string;
  label: string;
  icon?: React.ReactNode;
  disabled?: boolean;
}

interface TabsProps {
  tabs: Tab[];
  activeTab: string;
  onChange: (tabId: string) => void;
  variant?: 'line' | 'pill';
  className?: string;
}

export function Tabs({
  tabs,
  activeTab,
  onChange,
  variant = 'line',
  className
}: TabsProps) {
  const variants = {
    line: {
      container: 'border-b border-gray-200',
      tab: (isActive: boolean) => cn(
        'group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm',
        isActive
          ? 'border-blue-500 text-blue-600'
          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
      )
    },
    pill: {
      container: 'flex space-x-1',
      tab: (isActive: boolean) => cn(
        'group rounded-md py-2 px-3 flex items-center font-medium text-sm',
        isActive
          ? 'bg-blue-100 text-blue-700'
          : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
      )
    }
  };

  return (
    <div className={cn(variants[variant].container, className)}>
      <nav className="-mb-px flex space-x-8" aria-label="Tabs">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => !tab.disabled && onChange(tab.id)}
              disabled={tab.disabled}
              className={cn(
                variants[variant].tab(isActive),
                tab.disabled && 'opacity-50 cursor-not-allowed'
              )}
            >
              {tab.icon && (
                <span className={cn(
                  'mr-2',
                  isActive ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500'
                )}>
                  {tab.icon}
                </span>
              )}
              {tab.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}