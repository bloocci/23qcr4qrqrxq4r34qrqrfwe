import { cn } from '@/lib/utils';

interface RadioProps {
  value: string;
  name: string;
  checked: boolean;
  onChange: (value: string) => void;
  label?: string;
  disabled?: boolean;
  className?: string;
}

export function Radio({
  value,
  name,
  checked,
  onChange,
  label,
  disabled,
  className
}: RadioProps) {
  return (
    <label className={cn(
      'inline-flex items-center',
      disabled && 'opacity-50 cursor-not-allowed',
      className
    )}>
      <div className="relative flex items-center">
        <input
          type="radio"
          value={value}
          name={name}
          checked={checked}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className="sr-only"
        />
        <div
          className={cn(
            'h-5 w-5 rounded-full border transition-colors',
            checked
              ? 'border-blue-600'
              : 'border-gray-300',
            !disabled && 'hover:border-blue-500'
          )}
        >
          {checked && (
            <div className="absolute top-1/2 left-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-blue-600" />
          )}
        </div>
        {label && (
          <span className="ml-2 text-sm text-gray-900">{label}</span>
        )}
      </div>
    </label>
  );
}