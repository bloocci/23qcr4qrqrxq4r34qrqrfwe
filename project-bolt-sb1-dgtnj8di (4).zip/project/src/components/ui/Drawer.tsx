import { Fragment } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  position?: 'left' | 'right';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  className?: string;
}

export function Drawer({
  isOpen,
  onClose,
  title,
  children,
  position = 'right',
  size = 'md',
  className
}: DrawerProps) {
  if (!isOpen) return null;

  const sizes = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    full: 'max-w-screen-xl'
  };

  return (
    <Fragment>
      <div
        className="fixed inset-0 bg-black/25 backdrop-blur-sm z-50"
        aria-hidden="true"
        onClick={onClose}
      />
      <div
        className={cn(
          'fixed inset-y-0 z-50 flex',
          position === 'left' ? 'left-0' : 'right-0'
        )}
      >
        <div className={cn(
          'w-screen',
          sizes[size],
          'flex flex-col bg-white shadow-xl',
          className
        )}>
          {title && (
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-lg font-medium text-gray-900">{title}</h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          )}
          <div className="flex-1 overflow-y-auto">
            {children}
          </div>
        </div>
      </div>
    </Fragment>
  );
}