import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday } from 'date-fns';
import { cn } from '@/lib/utils';

interface CalendarProps {
  value?: Date;
  onChange?: (date: Date) => void;
  className?: string;
  disabledDates?: Date[];
  minDate?: Date;
  maxDate?: Date;
}

export function Calendar({
  value,
  onChange,
  className,
  disabledDates = [],
  minDate,
  maxDate
}: CalendarProps) {
  const [month, setMonth] = useState(value || new Date());

  const days = eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month)
  });

  const isDateDisabled = (date: Date) => {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;
    return disabledDates.some(disabledDate => isSameDay(date, disabledDate));
  };

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className={cn('p-3', className)}>
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1))}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h2 className="font-semibold text-gray-900">
          {format(month, 'MMMM yyyy')}
        </h2>
        <button
          onClick={() => setMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1))}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {weekDays.map(day => (
          <div
            key={day}
            className="h-8 flex items-center justify-center text-sm font-medium text-gray-500"
          >
            {day}
          </div>
        ))}
        {Array.from({ length: days[0].getDay() - 1 }).map((_, index) => (
          <div key={`empty-${index}`} />
        ))}
        {days.map(day => {
          const isSelected = value ? isSameDay(day, value) : false;
          const isDisabled = isDateDisabled(day);
          const isCurrent = isToday(day);

          return (
            <button
              key={day.toISOString()}
              onClick={() => !isDisabled && onChange?.(day)}
              disabled={isDisabled}
              className={cn(
                'h-8 flex items-center justify-center text-sm rounded-full',
                !isDisabled && 'hover:bg-gray-100',
                isSelected && 'bg-blue-600 text-white hover:bg-blue-700',
                !isSelected && !isSameMonth(day, month) && 'text-gray-400',
                isCurrent && !isSelected && 'text-blue-600 font-semibold',
                isDisabled && 'text-gray-300 cursor-not-allowed'
              )}
            >
              {format(day, 'd')}
            </button>
          );
        })}
      </div>
    </div>
  );
}