import { useState, useRef } from 'react';
import { Upload, X, File as FileIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onFileSelect: (files: File[]) => void;
  onFileRemove?: (file: File) => void;
  accept?: string;
  multiple?: boolean;
  maxSize?: number;
  className?: string;
  disabled?: boolean;
}

export function FileUpload({
  onFileSelect,
  onFileRemove,
  accept,
  multiple = false,
  maxSize,
  className,
  disabled
}: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (selectedFiles: FileList | null) => {
    if (!selectedFiles) return;

    const newFiles = Array.from(selectedFiles).filter(file => {
      if (maxSize && file.size > maxSize) {
        console.warn(`File ${file.name} exceeds maximum size of ${maxSize} bytes`);
        return false;
      }
      return true;
    });

    setFiles(prev => {
      const updatedFiles = multiple ? [...prev, ...newFiles] : newFiles;
      onFileSelect(updatedFiles);
      return updatedFiles;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleRemove = (file: File) => {
    setFiles(prev => {
      const updatedFiles = prev.filter(f => f !== file);
      onFileSelect(updatedFiles);
      onFileRemove?.(file);
      return updatedFiles;
    });
  };

  return (
    <div className={className}>
      <div
        className={cn(
          'relative border-2 border-dashed rounded-lg p-6',
          isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="text-center">
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <div className="mt-4 flex text-sm text-gray-600">
            <label
              htmlFor="file-upload"
              className={cn(
                'relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500',
                disabled && 'cursor-not-allowed opacity-50'
              )}
            >
              <span>Upload a file</span>
              <input
                id="file-upload"
                name="file-upload"
                type="file"
                ref={fileInputRef}
                className="sr-only"
                onChange={e => handleFileSelect(e.target.files)}
                accept={accept}
                multiple={multiple}
                disabled={disabled}
              />
            </label>
            <p className="pl-1">or drag and drop</p>
          </div>
          <p className="text-xs text-gray-500">
            {accept ? `Allowed files: ${accept}` : 'Any file type allowed'}
            {maxSize && ` up to ${Math.round(maxSize / 1024 / 1024)}MB`}
          </p>
        </div>
      </div>

      {files.length > 0 && (
        <ul className="mt-4 divide-y divide-gray-200">
          {files.map((file, index) => (
            <li key={index} className="py-3 flex items-center justify-between">
              <div className="flex items-center">
                <FileIcon className="h-5 w-5 text-gray-400" />
                <span className="ml-2 text-sm text-gray-900">{file.name}</span>
                <span className="ml-2 text-xs text-gray-500">
                  ({Math.round(file.size / 1024)}KB)
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleRemove(file)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}