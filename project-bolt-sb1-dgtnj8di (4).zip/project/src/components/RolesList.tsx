import { Edit2, Trash2 } from 'lucide-react';
import type { Role } from '../types';

interface RolesListProps {
  roles: Role[];
  onEdit: (role: Role) => void;
  onDelete: (roleId: string) => void;
}

export function RolesList({ roles, onEdit, onDelete }: RolesListProps) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">
          Roles
        </h3>
      </div>
      <div className="divide-y divide-gray-200">
        {roles.map((role) => (
          <div key={role.id} className="p-4 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: role.colorCode }}
                />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">
                    {role.name}
                  </h4>
                  <p className="text-sm text-gray-500 mt-1">
                    {role.description}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onEdit(role)}
                  className="p-1 text-gray-400 hover:text-gray-500"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => onDelete(role.id)}
                  className="p-1 text-gray-400 hover:text-red-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}