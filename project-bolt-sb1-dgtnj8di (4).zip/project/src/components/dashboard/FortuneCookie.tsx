import { useState, useEffect } from 'react';
import { Cookie } from 'lucide-react';

interface AdviceResponse {
  slip: {
    id: number;
    advice: string;
  };
}

export function FortuneCookie() {
  const [fortune, setFortune] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchFortune = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('https://api.adviceslip.com/advice', {
        cache: 'no-cache'
      });
      const data: AdviceResponse = await response.json();
      setFortune(data.slip.advice);
    } catch (error) {
      console.error('Error fetching fortune:', error);
      setFortune('A mysterious force prevents your fortune from being revealed...');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFortune();
  }, []);

  return (
    <div className="bg-white shadow rounded-lg h-[172px] flex flex-col">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
          <Cookie className="h-5 w-5 text-blue-600 mr-2" />
          Daily Fortune
        </h3>
      </div>
      <div className="flex-1 px-6 py-4 flex items-center">
        <div className={`w-full text-lg text-gray-900 ${isLoading ? 'animate-pulse' : ''}`}>
          {isLoading ? (
            <div className="h-6 bg-gray-200 rounded w-3/4" />
          ) : (
            <p className="italic">{fortune}</p>
          )}
        </div>
      </div>
    </div>
  );
}