import { useState, useEffect } from 'react';
import { Lightbulb as LightBulb } from 'lucide-react';

interface AdviceResponse {
  slip?: { id: number; advice: string };
  content?: string;
  error?: boolean;
}

// Curated workplace wisdom with humor
const WORKPLACE_WISDOM = [
  "Remember: The best way to get your manager's attention is to have a relaxing lunch break.",
  "Pro tip: If you type really loud, everyone will think you're being productive.",
  "Office survival guide: The earlier you are to a meeting, the longer you have to pretend to be busy on your phone.",
  "Workplace wisdom: Your salary is the bribe they give you to forget your dreams.",
  "Fun fact: The best ideas come either 5 minutes before you leave or during vacation.",
  "Career advice: Always look busy by carrying a piece of paper wherever you go.",
  "Office hack: If you can't find the answer, just say 'It's in the cloud' and sound confident.",
  "Remember: The office printer can sense fear and deadline pressure.",
  "Pro tip: The best time to schedule a meeting is right before lunch - no one talks too much.",
  "Workplace truth: Your inbox is like a black hole, the more you clear it, the more it grows.",
  "Life hack: Keep a jacket at your desk - it makes people think you might be leaving soon.",
  "Office wisdom: The probability of the break room being empty is inversely proportional to how much you need coffee.",
  "Career secret: The most important skill is looking attentive during meetings while thinking about lunch.",
  "Remember: Every office has that one person who thinks 'Reply All' is always necessary. Don't be that person.",
  "Pro tip: The best way to avoid unnecessary meetings is to look perpetually confused."
];

export function DailyWisdom() {
  const [wisdom, setWisdom] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchWisdom = async () => {
    try {
      setIsLoading(true);
      
      // Try to get workplace advice from Quotable API first
      const response = await fetch(
        'https://api.quotable.io/random?tags=wisdom,success&maxLength=100',
        { cache: 'no-cache' }
      );
      const data: AdviceResponse = await response.json();
      
      if (!response.ok || !data.content) {
        // Try Advice Slip API as backup
        const adviceResponse = await fetch('https://api.adviceslip.com/advice', {
          cache: 'no-cache'
        });
        const adviceData: AdviceResponse = await adviceResponse.json();
        
        if (!adviceData.slip?.advice || adviceData.slip.advice.length > 100) {
          // Use our curated wisdom if APIs fail or return unsuitable content
          const randomIndex = Math.floor(Math.random() * WORKPLACE_WISDOM.length);
          setWisdom(WORKPLACE_WISDOM[randomIndex]);
        } else {
          setWisdom(adviceData.slip.advice);
        }
      } else {
        setWisdom(data.content);
      }
    } catch (error) {
      // Fallback to our curated wisdom if all APIs fail
      const randomIndex = Math.floor(Math.random() * WORKPLACE_WISDOM.length);
      setWisdom(WORKPLACE_WISDOM[randomIndex]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWisdom();
    
    // Refresh wisdom every 4 hours
    const interval = setInterval(fetchWisdom, 4 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white shadow rounded-lg h-[172px] flex flex-col">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
          <LightBulb className="h-5 w-5 text-amber-500 mr-2" />
          Daily Wisdom
        </h3>
      </div>
      <div className="flex-1 px-6 py-4 flex items-center">
        <div className={`w-full text-lg text-gray-900 ${isLoading ? 'animate-pulse' : ''}`}>
          {isLoading ? (
            <div className="h-6 bg-gray-200 rounded w-3/4" />
          ) : (
            <p className="italic">{wisdom}</p>
          )}
        </div>
      </div>
    </div>
  );
}