import { useState, useEffect } from 'react';
import { Laugh } from 'lucide-react';

interface JokeResponse {
  type: string;
  setup?: string;
  delivery?: string;
  joke?: string;
  flags: {
    nsfw: boolean;
    religious: boolean;
    political: boolean;
    racist: boolean;
    sexist: boolean;
    explicit: boolean;
  };
  id: number;
  error?: boolean;
}

// Backup jokes in case API fails or returns inappropriate content
const WORKPLACE_JOKES = [
  "What did the employee say when the coffee machine broke? 'Strong feelings about this, need to espresso myself.'",
  "Why did the Excel sheet win an award? Because it exceeded expectations!",
  "What's a project manager's favorite type of music? Deadlines!",
  "Why did the meeting go to the doctor? Because it ran overtime!",
  "What did one office chair say to the other? 'How's it rolling?'",
  "Why don't programmers like meetings? They prefer arrays!",
  "What's an accountant's favorite time of day? Excel o'clock!",
  "Why did the keyboard go to the doctor? It had too many keys!",
  "What did the printer say to the paper? 'This isn't working out, we should see other sheets.'",
  "Why did the calendar look sad? It had too many dates!",
  "What's a manager's favorite snack? Microchips!",
  "Why did the office plant get promoted? It was outstanding in its field!",
  "What did one wall say to the other wall in the conference room? 'I'll meet you at the corner!'",
  "Why did the whiteboard quit? Too many markers against it!",
  "What's an office's favorite drink? Deadline punch!"
];

export function DailyChuckle() {
  const [joke, setJoke] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchJoke = async () => {
    try {
      setIsLoading(true);
      
      // Try multiple joke APIs in sequence for best results
      const apis = [
        // JokeAPI - Workplace safe jokes
        'https://v2.jokeapi.dev/joke/Programming,Pun,Spooky,Christmas?safe-mode=true&blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single',
        
        // Official Joke API
        'https://official-joke-api.appspot.com/random_joke',
        
        // icanhazdadjoke API
        'https://icanhazdadjoke.com/'
      ];

      for (const api of apis) {
        try {
          const response = await fetch(api, {
            headers: {
              'Accept': 'application/json',
              'User-Agent': 'Employee Scheduler (https://github.com/your-repo)'
            }
          });

          if (!response.ok) continue;

          const data = await response.json();
          
          // Handle different API response formats
          let jokeText = '';
          if (api.includes('jokeapi.dev')) {
            jokeText = data.joke;
          } else if (api.includes('official-joke-api')) {
            jokeText = `${data.setup} ${data.punchline}`;
          } else if (api.includes('icanhazdadjoke')) {
            jokeText = data.joke;
          }

          // Validate joke content
          if (jokeText && jokeText.length <= 150 && !containsInappropriateContent(jokeText)) {
            setJoke(jokeText);
            setIsLoading(false);
            return;
          }
        } catch (error) {
          console.warn(`Failed to fetch from ${api}:`, error);
          continue;
        }
      }

      // If all APIs fail or return unsuitable content, use our curated jokes
      const randomIndex = Math.floor(Math.random() * WORKPLACE_JOKES.length);
      setJoke(WORKPLACE_JOKES[randomIndex]);
      
    } catch (error) {
      console.error('Error fetching joke:', error);
      // Fallback to our curated jokes
      const randomIndex = Math.floor(Math.random() * WORKPLACE_JOKES.length);
      setJoke(WORKPLACE_JOKES[randomIndex]);
    } finally {
      setIsLoading(false);
    }
  };

  // Basic content filter
  const containsInappropriateContent = (text: string): boolean => {
    const inappropriateTerms = [
      'nsfw', 'adult', 'sex', 'drunk', 'alcohol', 'death', 'kill',
      'racist', 'religion', 'political', 'trump', 'biden', 'covid'
    ];
    return inappropriateTerms.some(term => 
      text.toLowerCase().includes(term)
    );
  };

  useEffect(() => {
    fetchJoke();
    
    // Refresh joke every hour
    const interval = setInterval(fetchJoke, 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white shadow rounded-lg h-[172px] flex flex-col">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
          <Laugh className="h-5 w-5 text-yellow-500 mr-2" />
          Daily Chuckle
        </h3>
      </div>
      <div className="flex-1 px-6 py-4 flex items-center">
        <div className={`w-full text-lg text-gray-900 ${isLoading ? 'animate-pulse' : ''}`}>
          {isLoading ? (
            <div className="h-6 bg-gray-200 rounded w-3/4" />
          ) : (
            <p className="italic">{joke}</p>
          )}
        </div>
      </div>
    </div>
  );
}