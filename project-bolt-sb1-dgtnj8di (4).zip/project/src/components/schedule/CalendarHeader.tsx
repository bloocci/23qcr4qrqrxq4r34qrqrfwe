import { format } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import type { ViewType } from '../../types';

interface CalendarHeaderProps {
  selectedDate: Date;
  view: ViewType;
  onNavigate: (direction: 'prev' | 'next') => void;
  onAddShift: () => void;
}

export function CalendarHeader({ selectedDate, view, onNavigate, onAddShift }: CalendarHeaderProps) {
  return (
    <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => onNavigate('prev')}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ChevronLeft className="h-5 w-5 text-gray-600" />
        </button>
        <h2 className="text-lg font-medium text-gray-900">
          {format(selectedDate, view === 'month' ? 'MMMM yyyy' : 'MMMM d, yyyy')}
        </h2>
        <button
          onClick={() => onNavigate('next')}
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <ChevronRight className="h-5 w-5 text-gray-600" />
        </button>
      </div>
      <button
        onClick={onAddShift}
        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Shift
      </button>
    </div>
  );
}