import { format, parseISO, isSameDay } from 'date-fns';
import { Coffee, Briefcase, Sun, Moon, Clock } from 'lucide-react';
import { cn } from '../../lib/utils';
import type { Employee, Shift } from '../../types';
import { getShiftsForDay } from '../../lib/utils';

interface WeekViewProps {
  days: Date[];
  employees: Employee[];
  shifts: Shift[];
  onShiftClick: (shift: Shift) => void;
}

export function WeekView({ days, employees, shifts, onShiftClick }: WeekViewProps) {
  const getShiftIcon = (hour: number) => {
    if (hour >= 5 && hour < 12) return <Coffee className="h-4 w-4" />;
    if (hour >= 12 && hour < 17) return <Briefcase className="h-4 w-4" />;
    if (hour >= 17 && hour < 22) return <Sun className="h-4 w-4" />;
    return <Moon className="h-4 w-4" />;
  };

  return (
    <div className="grid grid-cols-7 gap-4">
      {days.map((day) => (
        <div key={format(day, 'yyyy-MM-dd')} className="min-h-[200px] bg-gray-50 rounded-lg p-2">
          <div className="text-sm font-medium text-gray-900 mb-2">
            {format(day, 'EEE d')}
          </div>
          <div className="space-y-2">
            {employees.map(employee => {
              const dayShifts = getShiftsForDay(shifts, day).filter(shift => shift.employeeId === employee.id);
              return dayShifts.map(shift => {
                if (!shift.startTime || !shift.endTime) return null;

                const startTime = parseISO(shift.startTime);
                const endTime = parseISO(shift.endTime);
                const isRecruiting = shift.type === 'recruiting' || 
                                 shift.title?.toLowerCase().includes('interview') || 
                                 shift.title?.toLowerCase().includes('screening');

                return (
                  <div
                    key={shift.id}
                    onClick={() => onShiftClick(shift)}
                    className={cn(
                      "rounded-lg px-2 py-1 cursor-pointer transition-all hover:brightness-95",
                      isRecruiting && "border-2 border-white"
                    )}
                    style={{
                      backgroundColor: isRecruiting ? '#4F46E5' : employee.role.colorCode
                    }}
                  >
                    <div className="flex items-center justify-between text-white">
                      <span className="text-xs font-medium truncate">
                        {employee.firstName} {employee.lastName}
                      </span>
                      {getShiftIcon(startTime.getHours())}
                    </div>
                    <div className="text-xs text-white/90 flex items-center mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>
                        {format(startTime, 'h:mm a')} - {format(endTime, 'h:mm a')}
                      </span>
                    </div>
                    {shift.title && (
                      <div className="text-xs text-white/80 truncate mt-1">
                        {shift.title}
                      </div>
                    )}
                  </div>
                );
              });
            })}
          </div>
        </div>
      ))}
    </div>
  );
}