import { format, parseISO, isSameDay } from 'date-fns';
import { Coffee, Briefcase, Sun, Moon, Clock, MapPin } from 'lucide-react';
import { cn } from '../../lib/utils';
import type { Employee, Shift } from '../../types';

// Working hours - Include full range up to 7 PM (19:00)
const TIME_GRID_START = 8; // 8 AM
const TIME_GRID_END = 20; // 8 PM (to include the full 7 PM hour)
const HOURS = Array.from({ length: TIME_GRID_END - TIME_GRID_START }, (_, i) => i + TIME_GRID_START);

interface TimelineViewProps {
  selectedDate: Date;
  employees: Employee[];
  shifts: Shift[];
  onShiftClick: (shift: Shift) => void;
}

export function TimelineView({ 
  selectedDate, 
  employees, 
  shifts,
  onShiftClick
}: TimelineViewProps) {
  // Get shifts for the selected date
  const dayShifts = shifts.filter(shift => {
    if (!shift.startTime) return false;
    try {
      const shiftDate = parseISO(shift.startTime);
      return isSameDay(shiftDate, selectedDate);
    } catch (error) {
      console.warn('Invalid date format:', shift.startTime);
      return false;
    }
  });

  // Calculate position for a shift
  const calculateShiftPosition = (shift: Shift) => {
    try {
      const startTime = parseISO(shift.startTime);
      const endTime = parseISO(shift.endTime);
      const startHour = startTime.getHours();
      const endHour = endTime.getHours();
      const startMinutes = startTime.getMinutes();
      const endMinutes = endTime.getMinutes();
      
      // Clamp times to working hours
      const clampedStartHour = Math.max(TIME_GRID_START, Math.min(TIME_GRID_END - 1, startHour));
      const clampedEndHour = Math.max(TIME_GRID_START, Math.min(TIME_GRID_END - 1, endHour));
      
      const startPosition = clampedStartHour - TIME_GRID_START + (startMinutes / 60);
      const duration = (clampedEndHour - clampedStartHour) + ((endMinutes - startMinutes) / 60);
      const totalHours = TIME_GRID_END - TIME_GRID_START;
      
      return {
        left: `${(startPosition / totalHours) * 100}%`,
        width: `${(duration / totalHours) * 100}%`
      };
    } catch (error) {
      console.warn('Error calculating shift position:', error);
      return { left: '0%', width: '0%' };
    }
  };

  // Get shift icon based on time
  const getShiftIcon = (hour: number) => {
    if (hour >= 5 && hour < 12) return <Coffee className="h-4 w-4" />;
    if (hour >= 12 && hour < 17) return <Briefcase className="h-4 w-4" />;
    if (hour >= 17 && hour < 22) return <Sun className="h-4 w-4" />;
    return <Moon className="h-4 w-4" />;
  };

  // Calculate current time indicator position
  const getCurrentTimePosition = () => {
    const now = new Date();
    const hour = now.getHours();
    const minutes = now.getMinutes();
    
    if (hour < TIME_GRID_START || hour >= TIME_GRID_END) return null;
    
    const position = (hour - TIME_GRID_START + minutes / 60) / (TIME_GRID_END - TIME_GRID_START) * 100;
    return `${position}%`;
  };

  return (
    <div className="relative">
      {/* Time grid header */}
      <div className="grid grid-cols-[150px_1fr] gap-4">
        <div className="font-medium text-sm text-gray-500">Employees</div>
        <div className="grid grid-cols-[repeat(12,1fr)] border-l border-gray-200">
          {HOURS.map(hour => (
            <div key={hour} className="relative text-center">
              <div className="text-xs font-medium text-gray-500">
                {format(new Date().setHours(hour, 0, 0, 0), 'h:mm a')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Employee rows */}
      <div className="mt-4 space-y-4">
        {employees.map(employee => (
          <div key={employee.id} className="grid grid-cols-[150px_1fr] gap-4">
            {/* Employee info */}
            <div className="flex items-center">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: employee.role.colorCode }}
                />
                <span className="text-sm font-medium text-gray-900 truncate">
                  {employee.firstName} {employee.lastName}
                </span>
              </div>
            </div>

            {/* Timeline grid */}
            <div className="relative h-16 bg-gray-50 rounded-lg">
              {/* Hour lines */}
              <div className="absolute inset-0 grid grid-cols-[repeat(12,1fr)]">
                {HOURS.map(hour => (
                  <div key={hour} className="border-l border-gray-200 h-full" />
                ))}
              </div>

              {/* Current time indicator */}
              {isSameDay(selectedDate, new Date()) && getCurrentTimePosition() !== null && (
                <div 
                  className="absolute top-0 bottom-0 w-px bg-red-500 z-20"
                  style={{ left: getCurrentTimePosition() }}
                >
                  <div className="absolute -top-1 -left-1 h-2 w-2 rounded-full bg-red-500" />
                </div>
              )}

              {/* Shifts */}
              {dayShifts
                .filter(shift => shift.employeeId === employee.id)
                .map(shift => {
                  const position = calculateShiftPosition(shift);
                  const startTime = parseISO(shift.startTime);
                  const endTime = parseISO(shift.endTime);
                  const isRecruiting = shift.type === 'recruiting' || 
                                   shift.title?.toLowerCase().includes('interview') || 
                                   shift.title?.toLowerCase().includes('screening');

                  return (
                    <div
                      key={shift.id}
                      onClick={() => onShiftClick(shift)}
                      className={cn(
                        "absolute top-2 bottom-2 rounded-lg px-3 py-1 cursor-pointer transition-all hover:brightness-95 group overflow-hidden",
                        isRecruiting && "border-2 border-white"
                      )}
                      style={{
                        backgroundColor: isRecruiting ? '#4F46E5' : employee.role.colorCode,
                        left: position.left,
                        width: position.width
                      }}
                    >
                      <div className="h-full flex flex-col justify-center">
                        <div className="flex items-center justify-between text-white">
                          <span className="text-sm font-medium truncate">
                            {shift.title || 'Untitled Shift'}
                          </span>
                          {getShiftIcon(startTime.getHours())}
                        </div>
                        <div className="text-xs text-white/90 flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>
                            {format(startTime, 'h:mm a')} - {format(endTime, 'h:mm a')}
                          </span>
                        </div>
                      </div>
                      {isRecruiting && (
                        <div className="absolute -top-1 -right-1">
                          <span className="flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}