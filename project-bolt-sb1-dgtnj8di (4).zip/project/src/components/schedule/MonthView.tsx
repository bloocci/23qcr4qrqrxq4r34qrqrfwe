import { format, parseISO, isSameMonth, isSameDay } from 'date-fns';
import { Coffee, Briefcase, Sun, Moon, Clock } from 'lucide-react';
import { cn } from '../../lib/utils';
import type { Employee, Shift } from '../../types';
import { getShiftsForDay } from '../../lib/utils';

interface MonthViewProps {
  days: Date[];
  selectedDate: Date;
  employees: Employee[];
  shifts: Shift[];
  onShiftClick: (shift: Shift) => void;
}

export function MonthView({ 
  days, 
  selectedDate, 
  employees, 
  shifts,
  onShiftClick 
}: MonthViewProps) {
  const getShiftIcon = (hour: number) => {
    if (hour >= 5 && hour < 12) return <Coffee className="h-3 w-3" />;
    if (hour >= 12 && hour < 17) return <Briefcase className="h-3 w-3" />;
    if (hour >= 17 && hour < 22) return <Sun className="h-3 w-3" />;
    return <Moon className="h-3 w-3" />;
  };

  return (
    <div className="grid grid-cols-7 gap-px bg-gray-200">
      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
        <div key={day} className="bg-gray-50 p-2 text-sm font-medium text-gray-900">
          {day}
        </div>
      ))}
      {days.map((day) => {
        const dayShifts = getShiftsForDay(shifts, day);
        const isCurrentMonth = isSameMonth(day, selectedDate);

        return (
          <div
            key={day.toString()}
            className={cn(
              "min-h-[120px] bg-white p-2",
              !isCurrentMonth && "bg-gray-50"
            )}
          >
            <p className={cn(
              "text-sm font-medium",
              isCurrentMonth ? "text-gray-900" : "text-gray-400"
            )}>
              {format(day, 'd')}
            </p>
            <div className="mt-1 space-y-1 max-h-[100px] overflow-y-auto">
              {dayShifts.map(shift => {
                if (!shift.startTime || !shift.endTime) return null;

                const startTime = parseISO(shift.startTime);
                const endTime = parseISO(shift.endTime);
                const isRecruiting = shift.type === 'recruiting' || 
                                 shift.title?.toLowerCase().includes('interview') || 
                                 shift.title?.toLowerCase().includes('screening');
                const employee = employees.find(e => e.id === shift.employeeId);

                if (!employee) return null;

                return (
                  <div
                    key={shift.id}
                    onClick={() => onShiftClick(shift)}
                    className={cn(
                      "rounded px-1 py-0.5 cursor-pointer transition-all hover:brightness-95 text-white",
                      isRecruiting && "border border-white"
                    )}
                    style={{
                      backgroundColor: isRecruiting ? '#4F46E5' : employee.role.colorCode
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs truncate">
                        {employee.firstName} {employee.lastName}
                      </span>
                      {getShiftIcon(startTime.getHours())}
                    </div>
                    <div className="text-xs opacity-90 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {format(startTime, 'h:mm a')}
                    </div>
                    {shift.title && (
                      <div className="text-xs opacity-80 truncate">
                        {shift.title}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}