import { format, parseISO, isSameDay } from 'date-fns';
import { Coffee, Briefcase, Sun, Moon, Clock, MapPin } from 'lucide-react';
import { cn } from '../../lib/utils';
import type { Employee, Shift } from '../../types';
import { getShiftsForDay } from '../../lib/utils';

interface DayViewProps {
  selectedDate: Date;
  employees: Employee[];
  shifts: Shift[];
  onShiftClick: (shift: Shift) => void;
  onTimeSlotClick: (date: Date, hour: number) => void;
}

export function DayView({ selectedDate, employees, shifts, onShiftClick, onTimeSlotClick }: DayViewProps) {
  // Get shifts for a specific employee on the selected date
  const getEmployeeShifts = (employee: Employee) => {
    return getShiftsForDay(shifts, selectedDate).filter(shift => shift.employeeId === employee.id);
  };

  // Get shift icon based on time
  const getShiftIcon = (hour: number) => {
    if (hour >= 5 && hour < 12) return <Coffee className="h-4 w-4" />;
    if (hour >= 12 && hour < 17) return <Briefcase className="h-4 w-4" />;
    if (hour >= 17 && hour < 22) return <Sun className="h-4 w-4" />;
    return <Moon className="h-4 w-4" />;
  };

  // Calculate current time indicator position
  const getCurrentTimePosition = () => {
    const now = new Date();
    const hour = now.getHours();
    const minutes = now.getMinutes();
    
    if (hour < 8 || hour >= 19) return null;
    
    const position = (hour - 8 + minutes / 60) / (19 - 8) * 100;
    return `${position}%`;
  };

  return (
    <div className="space-y-4">
      {/* Employee rows */}
      <div className="relative space-y-4">
        {/* Current time indicator */}
        {isSameDay(selectedDate, new Date()) && getCurrentTimePosition() !== null && (
          <div 
            className="absolute left-[150px] right-0 h-px bg-red-500 z-20"
            style={{ top: getCurrentTimePosition() }}
          >
            <div className="absolute -left-1 -top-1 h-2 w-2 rounded-full bg-red-500" />
          </div>
        )}

        {employees.map(employee => {
          const employeeShifts = getEmployeeShifts(employee);

          return (
            <div key={employee.id} className="relative">
              {/* Employee info */}
              <div className="absolute left-0 top-0 w-[150px] h-full flex items-start pr-4">
                <div className="w-full bg-white p-3 rounded-lg shadow-sm">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: employee.role.colorCode }}
                    />
                    <span className="text-sm font-medium text-gray-900 truncate">
                      {employee.firstName} {employee.lastName}
                    </span>
                  </div>
                  <div className="mt-1 text-xs text-gray-500">
                    {employee.role.name}
                  </div>
                </div>
              </div>

              {/* Time grid */}
              <div className="ml-[150px] h-24 bg-gray-50 rounded-lg relative">
                {/* Hour markers */}
                <div className="absolute inset-0 grid grid-cols-[repeat(11,1fr)]">
                  {Array.from({ length: 11 }, (_, i) => i + 8).map(hour => (
                    <div key={hour} className="border-l border-gray-200 h-full" />
                  ))}
                </div>

                {/* Shifts */}
                {employeeShifts.map(shift => {
                  const startTime = parseISO(shift.startTime);
                  const endTime = parseISO(shift.endTime);
                  const isRecruiting = shift.type === 'recruiting' || 
                                   shift.title?.toLowerCase().includes('interview') || 
                                   shift.title?.toLowerCase().includes('screening');

                  // Calculate position and width
                  const startHour = startTime.getHours() + startTime.getMinutes() / 60;
                  const endHour = endTime.getHours() + endTime.getMinutes() / 60;
                  const totalHours = 11; // 8 AM to 7 PM
                  const left = Math.max(0, ((startHour - 8) / totalHours) * 100);
                  const width = Math.min(100 - left, ((endHour - startHour) / totalHours) * 100);

                  return (
                    <div
                      key={shift.id}
                      onClick={() => onShiftClick(shift)}
                      className={cn(
                        "absolute top-2 bottom-2 rounded-lg px-3 py-2 cursor-pointer transition-all hover:brightness-95 group",
                        isRecruiting && "border-2 border-white"
                      )}
                      style={{
                        backgroundColor: isRecruiting ? '#4F46E5' : employee.role.colorCode,
                        left: `${left}%`,
                        width: `${width}%`
                      }}
                    >
                      <div className="h-full flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between text-white">
                            <span className="text-sm font-medium truncate">
                              {shift.title || 'Untitled Shift'}
                            </span>
                            {getShiftIcon(startTime.getHours())}
                          </div>
                          <div className="text-xs text-white/90 flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>
                              {format(startTime, 'h:mm a')} - {format(endTime, 'h:mm a')}
                            </span>
                          </div>
                        </div>
                        {shift.notes && (
                          <div className="text-xs text-white/80 truncate mt-1">
                            {shift.notes.split('\n')[0]}
                          </div>
                        )}
                      </div>
                      {isRecruiting && (
                        <div className="absolute -top-1 -right-1">
                          <span className="flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Click target for adding new shifts */}
                <div 
                  className="absolute inset-0" 
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const relativeX = e.clientX - rect.left;
                    const percentageX = relativeX / rect.width;
                    const hour = Math.floor(percentageX * 11 + 8);
                    onTimeSlotClick(selectedDate, hour);
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}