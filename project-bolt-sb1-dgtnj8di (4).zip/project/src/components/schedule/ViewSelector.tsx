import { cn } from '../../lib/utils';
import type { ViewType } from '../../types';

interface ViewSelectorProps {
  view: ViewType;
  onViewChange: (view: ViewType) => void;
}

export function ViewSelector({ view, onViewChange }: ViewSelectorProps) {
  return (
    <div className="flex rounded-lg shadow-sm">
      <button
        onClick={() => onViewChange('timeline')}
        className={cn(
          "px-4 py-2 text-sm font-medium rounded-l-lg",
          view === 'timeline'
            ? "bg-blue-600 text-white"
            : "bg-white text-gray-700 hover:bg-gray-50"
        )}
      >
        Timeline
      </button>
      <button
        onClick={() => onViewChange('week')}
        className={cn(
          "px-4 py-2 text-sm font-medium -ml-px",
          view === 'week'
            ? "bg-blue-600 text-white"
            : "bg-white text-gray-700 hover:bg-gray-50"
        )}
      >
        Week
      </button>
      <button
        onClick={() => onViewChange('month')}
        className={cn(
          "px-4 py-2 text-sm font-medium rounded-r-lg -ml-px",
          view === 'month'
            ? "bg-blue-600 text-white"
            : "bg-white text-gray-700 hover:bg-gray-50"
        )}
      >
        Month
      </button>
    </div>
  );
}