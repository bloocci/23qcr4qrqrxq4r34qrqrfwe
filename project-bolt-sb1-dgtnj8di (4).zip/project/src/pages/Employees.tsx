import { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useEmployeeStore } from '../store/employeeStore';
import { useScheduleStore } from '../store/scheduleStore';
import { 
  Plus, Edit2, Trash2, Phone, Mail, 
  UserPlus, Building2, Filter, Search,
  Calendar, AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';
import { AddEmployeeForm } from '../components/forms/AddEmployeeForm';
import { AddRoleForm } from '../components/forms/AddRoleForm';
import { RolesList } from '../components/RolesList';
import { DeleteConfirmationDialog } from '../components/ui/DeleteConfirmationDialog';
import type { Employee, Role } from '../types';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

export function Employees() {
  const { user } = useAuthStore();
  const { employees, roles, addEmployee, updateEmployee, deleteEmployee, addRole, updateRole, deleteRole } = useEmployeeStore();
  const { deleteEmployeeShifts } = useScheduleStore();
  
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [showAddRole, setShowAddRole] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [activeTab, setActiveTab] = useState<'employees' | 'roles'>('employees');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<string>('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);

  const handleAddEmployee = (data: any) => {
    const selectedRole = roles.find(role => role.id === data.roleId);
    if (!selectedRole) return;

    const newEmployee: Employee = {
      id: Math.random().toString(36).substr(2, 9),
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
      role: selectedRole,
      schedule: data.schedule,
      startDate: data.startDate,
      phone: data.phone
    };

    addEmployee(newEmployee);
    setShowAddEmployee(false);
    toast.success('Employee added successfully');
  };

  const handleEditEmployee = (data: Employee) => {
    updateEmployee(data);
    setSelectedEmployee(null);
    toast.success('Employee updated successfully');
  };

  const handleDeleteClick = (employee: Employee) => {
    setEmployeeToDelete(employee);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = (deleteAppointments: boolean = false) => {
    if (!employeeToDelete) return;

    if (deleteAppointments) {
      deleteEmployeeShifts(employeeToDelete.id);
    }
    deleteEmployee(employeeToDelete.id);
    setDeleteDialogOpen(false);
    setEmployeeToDelete(null);
    toast.success('Employee deleted successfully');
  };

  const handleAddRole = (data: Omit<Role, 'id'>) => {
    const newRole: Role = {
      id: Math.random().toString(36).substr(2, 9),
      name: data.name,
      description: data.description,
      colorCode: data.colorCode
    };
    addRole(newRole);
    setShowAddRole(false);
    toast.success('Role added successfully');
  };

  const filteredEmployees = employees.filter(emp => {
    const searchMatch = 
      emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (emp.email?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);
    const roleMatch = filterRole ? emp.role.id === filterRole : true;
    return searchMatch && roleMatch;
  });

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-2xl font-semibold text-gray-900">Employee Management</h1>
          <p className="mt-2 text-sm text-gray-700">
            Manage your team members and roles
          </p>
        </div>
        <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-3">
          <button
            onClick={() => setShowAddRole(true)}
            className="inline-flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            <Building2 className="h-4 w-4 mr-2" />
            Add Role
          </button>
          <button
            onClick={() => setShowAddEmployee(true)}
            className="inline-flex items-center justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Add Employee
          </button>
        </div>
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('employees')}
            className={cn(
              "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm",
              activeTab === 'employees'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            )}
          >
            Employees
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={cn(
              "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm",
              activeTab === 'roles'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            )}
          >
            Roles
          </button>
        </nav>
      </div>

      {activeTab === 'employees' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="flex-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                placeholder="Search employees..."
              />
            </div>
            <div className="w-full sm:w-48">
              <select
                value={filterRole}
                onChange={(e) => setFilterRole(e.target.value)}
                className="block w-full sm:text-sm border-gray-300 rounded-md"
              >
                <option value="">All Roles</option>
                {roles.map(role => (
                  <option key={role.id} value={role.id}>{role.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <ul className="divide-y divide-gray-200">
              {filteredEmployees.map((employee) => (
                <li key={employee.id} className="hover:bg-gray-50">
                  <div className="px-4 py-4 flex items-center sm:px-6">
                    <div className="min-w-0 flex-1 sm:flex sm:items-center sm:justify-between">
                      <div>
                        <div className="flex items-center">
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white text-lg font-semibold"
                            style={{ backgroundColor: employee.role.colorCode }}
                          >
                            {employee.firstName.charAt(0)}{employee.lastName.charAt(0)}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {employee.firstName} {employee.lastName}
                            </div>
                            <div className="mt-1 flex items-center space-x-4 text-sm text-gray-500">
                              {employee.email && (
                                <span className="flex items-center">
                                  <Mail className="h-4 w-4 mr-1" />
                                  {employee.email}
                                </span>
                              )}
                              {employee.phone && (
                                <span className="flex items-center">
                                  <Phone className="h-4 w-4 mr-1" />
                                  {employee.phone}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="mt-2">
                          <span 
                            className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
                            style={{ 
                              backgroundColor: `${employee.role.colorCode}20`,
                              color: employee.role.colorCode 
                            }}
                          >
                            {employee.role.name}
                          </span>
                          <span className="ml-2 text-xs text-gray-500">
                            Started {format(new Date(employee.startDate), 'MMM d, yyyy')}
                          </span>
                        </div>
                      </div>
                      <div className="mt-4 flex-shrink-0 sm:mt-0 sm:ml-5">
                        <div className="flex space-x-4">
                          <button
                            onClick={() => {
                              setSelectedEmployee(employee);
                              setShowAddEmployee(true);
                            }}
                            className="text-gray-400 hover:text-gray-500"
                            title="Edit employee"
                          >
                            <Edit2 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(employee)}
                            className="text-gray-400 hover:text-red-500"
                            title="Delete employee"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {activeTab === 'roles' && (
        <RolesList
          roles={roles}
          onEdit={updateRole}
          onDelete={deleteRole}
        />
      )}

      {showAddEmployee && (
        <AddEmployeeForm
          roles={roles}
          onClose={() => {
            setShowAddEmployee(false);
            setSelectedEmployee(null);
          }}
          onSubmit={selectedEmployee ? handleEditEmployee : handleAddEmployee}
          onAddRole={handleAddRole}
          initialData={selectedEmployee}
          mode={selectedEmployee ? 'edit' : 'create'}
        />
      )}

      {showAddRole && (
        <AddRoleForm
          onClose={() => setShowAddRole(false)}
          onSubmit={handleAddRole}
        />
      )}

      <DeleteConfirmationDialog
        isOpen={deleteDialogOpen}
        onClose={() => {
          setDeleteDialogOpen(false);
          setEmployeeToDelete(null);
        }}
        onConfirm={handleDeleteConfirm}
        title="Delete Employee"
        message="Are you sure you want to delete this employee?"
        itemName={employeeToDelete ? `${employeeToDelete.firstName} ${employeeToDelete.lastName}` : undefined}
        showDeleteRelated={true}
        deleteRelatedMessage="Would you like to delete all associated appointments and shifts for this employee as well?"
      />
    </div>
  );
}