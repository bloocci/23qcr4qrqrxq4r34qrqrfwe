import { useState, useMemo } from 'react';
import { useAuthStore } from '../store/authStore';
import { useEmployeeStore } from '../store/employeeStore';
import { useScheduleStore } from '../store/scheduleStore';
import { 
  Calendar, Users, Clock, AlertCircle, TrendingUp, 
  CheckCircle, Bell, Sun, Cloud, Wind, Droplets,
  ChevronRight, ArrowUpRight, ArrowDownRight,
  UserPlus, CalendarPlus, MessageSquarePlus,
  Coffee, Briefcase, Moon, MapPin
} from 'lucide-react';
import { format, isToday, isPast, addDays, isSameDay, subWeeks, parseISO, isWithinInterval } from 'date-fns';
import type { Shift } from '../types';
import { DailyChuckle } from '../components/dashboard/DailyChuckle';

interface WeatherInfo {
  temp: number;
  condition: 'sunny' | 'cloudy' | 'rainy' | 'windy' | 'snowy' | 'stormy' | 'drizzle';
  humidity: number;
  windSpeed: number;
  feelsLike: number;
  description: string;
  location: string;
}

interface ShiftWithEmployee extends Shift {
  employee?: {
    firstName: string;
    lastName: string;
    role: {
      colorCode: string;
    };
  };
}

interface Notification {
  id: string;
  type: 'warning' | 'success' | 'info';
  message: string;
  time: string;
}

// Helper function to safely parse dates
const safeParseDate = (dateString: string | undefined | null) => {
  if (!dateString) return null;
  try {
    return parseISO(dateString);
  } catch {
    return null;
  }
};

// Helper function to convert weather code to our condition type
const getWeatherCondition = (code: number): WeatherInfo['condition'] => {
  // Weather codes from Open-Meteo API
  if (code >= 95) return 'stormy';    // Thunderstorm
  if (code >= 80) return 'rainy';     // Rain
  if (code >= 71) return 'snowy';     // Snow
  if (code >= 61) return 'rainy';     // Rain
  if (code >= 51) return 'drizzle';   // Drizzle
  if (code >= 45) return 'cloudy';    // Foggy
  if (code >= 1) return 'cloudy';     // Partly cloudy
  return 'sunny';                     // Clear sky
};

export function Dashboard() {
  const { user } = useAuthStore();
  const { employees } = useEmployeeStore();
  const { shifts } = useScheduleStore();
  
  // Calculate dashboard stats
  const stats = useMemo(() => {
    const now = new Date();
    const lastWeekStart = subWeeks(now, 1);

    // Helper function to check if a shift is active now
    const isShiftActive = (shift: Shift) => {
      const startTime = safeParseDate(shift.startTime);
      const endTime = safeParseDate(shift.endTime);
      if (!startTime || !endTime) return false;
      
      const currentTime = now.getTime();
      return currentTime >= startTime.getTime() && currentTime <= endTime.getTime();
    };

    // Get currently working employees
    const activeShifts = shifts.filter(isShiftActive);
    const workingEmployees = new Set(activeShifts.map(shift => shift.employeeId)).size;

    // Get today's shifts
    const todayShifts = shifts.filter(shift => {
      const startDate = safeParseDate(shift.startTime);
      return startDate && isToday(startDate);
    });

    // Get last week's shifts
    const lastWeekShifts = shifts.filter(shift => {
      const startDate = safeParseDate(shift.startTime);
      return startDate && isWithinInterval(startDate, { start: lastWeekStart, end: now });
    });

    // Calculate shift trend percentage
    const shiftChange = lastWeekShifts.length > 0 
      ? ((todayShifts.length - lastWeekShifts.length) / lastWeekShifts.length) * 100
      : 0;

    // Calculate completed shifts
    const completedShifts = shifts.filter(shift => {
      const endDate = safeParseDate(shift.endTime);
      return endDate && isPast(endDate);
    }).length;

    return {
      totalEmployees: employees.length,
      todayShifts: todayShifts.length,
      upcomingShifts: shifts.filter(shift => {
        const startDate = safeParseDate(shift.startTime);
        return startDate && !isPast(startDate);
      }).length,
      completedShifts,
      workingEmployees,
      trends: {
        employees: 0,
        shifts: shiftChange,
        completion: completedShifts > 0 ? (completedShifts / shifts.length) * 100 : 0
      }
    };
  }, [employees, shifts]);

  // Get recent shifts with employee data
  const recentShifts = useMemo(() => {
    return shifts
      .filter(shift => {
        const startDate = safeParseDate(shift.startTime);
        return startDate && (isToday(startDate) || !isPast(startDate));
      })
      .sort((a, b) => {
        const dateA = safeParseDate(a.startTime) || new Date();
        const dateB = safeParseDate(b.startTime) || new Date();
        return dateA.getTime() - dateB.getTime();
      })
      .slice(0, 5)
      .map(shift => ({
        ...shift,
        employee: employees.find(emp => emp.id === shift.employeeId)
      }))
      .filter((shift): shift is ShiftWithEmployee & { employee: NonNullable<ShiftWithEmployee['employee']> } => 
        !!shift.employee
      );
  }, [shifts, employees]);

  // Mock notifications
  const [notifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'warning',
      message: `${recentShifts[0]?.employee?.firstName || 'An employee'} has a shift starting soon`,
      time: '10 minutes ago'
    },
    {
      id: '2',
      type: 'success',
      message: `${stats.completedShifts} shifts completed today`,
      time: '2 hours ago'
    },
    {
      id: '3',
      type: 'info',
      message: `${stats.workingEmployees} employees currently working`,
      time: '4 hours ago'
    }
  ]);

  const [weather] = useState<WeatherInfo>({
    temp: 72,
    condition: 'sunny',
    humidity: 45,
    windSpeed: 8,
    feelsLike: 74,
    description: 'Clear sky',
    location: 'Minneapolis, MN 55413'
  });

  const getWeatherIcon = (condition: WeatherInfo['condition']) => {
    switch (condition) {
      case 'sunny': return <Sun className="h-8 w-8 text-yellow-500" />;
      case 'cloudy': return <Cloud className="h-8 w-8 text-gray-500" />;
      case 'rainy': return <Droplets className="h-8 w-8 text-blue-500" />;
      case 'windy': return <Wind className="h-8 w-8 text-blue-300" />;
    }
  };

  const getTrendIcon = (value: number) => {
    if (value > 0) {
      return <ArrowUpRight className="h-4 w-4 text-green-500" />;
    }
    return <ArrowDownRight className="h-4 w-4 text-red-500" />;
  };

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'warning': return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'info': return <Bell className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">
            Welcome back, {user?.firstName}!
          </h1>
        </div>
        <div className="text-sm text-gray-500">
          {format(new Date(), 'EEEE, MMMM do, yyyy')}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Employees */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Employees
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.totalEmployees}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <span className="font-medium text-blue-700 hover:text-blue-900">
                View all employees
              </span>
            </div>
          </div>
        </div>

        {/* Today's Shifts */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Today's Shifts
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.todayShifts}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold">
                      {getTrendIcon(stats.trends.shifts)}
                      <span className={stats.trends.shifts > 0 ? "text-green-600" : "text-red-600"}>
                        {Math.abs(Math.round(stats.trends.shifts))}%
                      </span>
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <span className="font-medium text-green-700 hover:text-green-900">
                View schedule
              </span>
            </div>
          </div>
        </div>

        {/* Currently Working */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Briefcase className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Currently Working
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.workingEmployees}
                    </div>
                    <div className="ml-2 text-sm text-gray-500">
                      employees
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <span className="font-medium text-purple-700 hover:text-purple-900">
                View active shifts
              </span>
            </div>
          </div>
        </div>

        {/* Completed Shifts */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-indigo-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Completed Shifts
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.completedShifts}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      {Math.round(stats.trends.completion)}%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <span className="font-medium text-indigo-700 hover:text-indigo-900">
                View history
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Daily Chuckle */}
          <DailyChuckle />

          {/* Shift Timeline */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-6 py-5 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                Shift Timeline
              </h3>
              <div className="flex space-x-2">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Completed
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  <Clock className="h-3 w-3 mr-1" />
                  Active
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                  <Calendar className="h-3 w-3 mr-1" />
                  Upcoming
                </span>
              </div>
            </div>
            <div className="p-6">
              <div className="relative">
                <div className="absolute top-0 bottom-0 left-4 w-0.5 bg-gray-200" />
                <div className="space-y-8">
                  {recentShifts.map((shift) => {
                    if (!shift.employee) return null;
                    
                    const startTime = parseISO(shift.startTime);
                    const endTime = parseISO(shift.endTime);
                    const isComplete = isPast(endTime) && !isToday(startTime);
                    const isActive = isToday(startTime) && !isPast(endTime);
                    const isFuture = !isToday(startTime) && !isPast(startTime);

                    const getShiftIcon = () => {
                      const hour = startTime.getHours();
                      if (hour >= 5 && hour < 12) return <Coffee className="h-4 w-4" />;
                      if (hour >= 12 && hour < 17) return <Briefcase className="h-4 w-4" />;
                      if (hour >= 17 && hour < 22) return <Sun className="h-4 w-4" />;
                      return <Moon className="h-4 w-4" />;
                    };

                    return (
                      <div key={shift.id} className="relative group">
                        <div className="flex items-center">
                          <div 
                            className={`absolute left-0 h-8 w-8 rounded-full border-2 flex items-center justify-center transition-colors duration-200 ${
                              isComplete ? 'bg-green-100 border-green-500' :
                              isActive ? 'bg-blue-100 border-blue-500' :
                              'bg-gray-100 border-gray-500'
                            }`}
                          >
                            {isComplete ? (
                              <CheckCircle className="h-4 w-4 text-green-500" />
                            ) : isActive ? (
                              <Clock className="h-4 w-4 text-blue-500" />
                            ) : (
                              <Calendar className="h-4 w-4 text-gray-500" />
                            )}
                          </div>
                          <div className="ml-12 w-full">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <div 
                                  className="w-2 h-2 rounded-full mr-2"
                                  style={{ backgroundColor: shift.employee.role.colorCode }}
                                />
                                <h4 className="text-sm font-medium text-gray-900">
                                  {shift.employee.firstName} {shift.employee.lastName}
                                </h4>
                                <span className="ml-2 text-sm text-gray-500">
                                  • {shift.title || 'Untitled Shift'}
                                </span>
                              </div>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                {getShiftIcon()}
                                <span>
                                  {format(startTime, 'h:mm a')} - {format(endTime, 'h:mm a')}
                                </span>
                              </div>
                            </div>
                            <div className="mt-2 flex items-start">
                              <div className="flex items-center text-sm text-gray-500 bg-gray-50 rounded-md px-2 py-1">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span>{shift.notes || 'No additional notes'}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Sidebar */}
        <div className="space-y-6">
          {/* Weather Widget */}
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-200">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                {weather.location}
              </h3>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {getWeatherIcon(weather.condition)}
                  <div className="ml-4">
                    <div className="text-3xl font-semibold text-gray-900">
                      {weather.temp}°F
                    </div>
                    <div className="text-sm text-gray-500 capitalize">
                      {weather.description}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-500">
                    Feels like {weather.feelsLike}°F
                  </div>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Droplets className="h-4 w-4 mr-1" />
                    Humidity: {weather.humidity}%
                  </div>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Wind className="h-4 w-4 mr-1" />
                    Wind: {weather.windSpeed} mph
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-200">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                Recent Notifications
              </h3>
            </div>
            <div className="divide-y divide-gray-200">
              {notifications.map((notification) => (
                <div key={notification.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="ml-3 w-0 flex-1">
                      <p className="text-sm text-gray-900">
                        {notification.message}
                      </p>
                      <p className="mt-1 text-sm text-gray-500">
                        {notification.time}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}