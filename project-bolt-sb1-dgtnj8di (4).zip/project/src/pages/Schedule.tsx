import { useState, useMemo } from 'react';
import { useEmployeeStore } from '../store/employeeStore';
import { useScheduleStore } from '../store/scheduleStore';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, addDays, parseISO } from 'date-fns';
import type { Shift, ViewType } from '../types';
import { ViewSelector } from '../components/schedule/ViewSelector';
import { CalendarHeader } from '../components/schedule/CalendarHeader';
import { WeekView } from '../components/schedule/WeekView';
import { MonthView } from '../components/schedule/MonthView';
import { TimelineView } from '../components/schedule/TimelineView';
import { EditShiftForm } from '../components/forms/EditShiftForm';

export function Schedule() {
  const { employees, roles } = useEmployeeStore();
  const { shifts, addShift, updateShift, deleteShift, lastSettings, setLastSettings } = useScheduleStore();
  
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState<ViewType>('timeline');
  const [showModal, setShowModal] = useState(false);
  const [selectedShift, setSelectedShift] = useState<Shift | null>(null);
  const [filterRole, setFilterRole] = useState<string>('');
  const [initialHour, setInitialHour] = useState(9);

  // Filter employees based on selected role
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => !filterRole || emp.role.id === filterRole);
  }, [employees, filterRole]);

  // Get days to display based on view
  const daysToShow = useMemo(() => {
    if (view === 'week') {
      const start = startOfWeek(selectedDate, { weekStartsOn: 1 });
      return eachDayOfInterval({ start, end: endOfWeek(selectedDate, { weekStartsOn: 1 }) });
    } else {
      const start = startOfWeek(selectedDate, { weekStartsOn: 1 });
      const end = addDays(start, 41); // Show 6 weeks
      return eachDayOfInterval({ start, end });
    }
  }, [selectedDate, view]);

  const handleEventClick = (shift: Shift) => {
    // When editing a shift, store its settings
    if (shift.recurringId) {
      const startTime = parseISO(shift.startTime);
      const endTime = parseISO(shift.endTime);
      const durationHours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
      
      setLastSettings({
        ...lastSettings,
        isRecurring: true,
        recurringDays: shift.recurringDays?.split(',') || [],
        recurringDuration: shift.recurringUntil ? 
          Math.ceil((new Date(shift.recurringUntil).getTime() - startTime.getTime()) / (1000 * 60 * 60 * 24)) : 
          30,
        shiftDuration: durationHours,
        employeeId: shift.employeeId,
        title: shift.title,
        notes: shift.notes
      });
    }
    setSelectedShift(shift);
    setShowModal(true);
  };

  const handleFormSubmit = (data: any) => {
    const shiftData = {
      id: selectedShift?.id || Math.random().toString(36).substr(2, 9),
      employeeId: data.employeeId,
      startTime: data.startTime,
      endTime: data.endTime,
      title: data.title,
      notes: data.notes,
      type: data.type || 'regular',
      recurringId: data.recurringId,
      recurringDays: data.recurringDays,
      recurringUntil: data.recurringUntil
    };

    // Store settings for future use
    const startTime = parseISO(shiftData.startTime);
    const endTime = parseISO(shiftData.endTime);
    const durationHours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);

    setLastSettings({
      ...lastSettings,
      isRecurring: !!shiftData.recurringId,
      recurringDays: shiftData.recurringDays?.split(',') || [],
      recurringDuration: shiftData.recurringUntil ? 
        Math.ceil((new Date(shiftData.recurringUntil).getTime() - startTime.getTime()) / (1000 * 60 * 60 * 24)) : 
        30,
      shiftDuration: durationHours,
      employeeId: shiftData.employeeId,
      title: shiftData.title,
      notes: shiftData.notes
    });

    if (selectedShift?.id) {
      updateShift(shiftData);
    } else {
      addShift(shiftData);
    }
    setShowModal(false);
    setSelectedShift(null);
  };

  const handleDelete = (id: string, deleteRecurring?: boolean) => {
    deleteShift(id, deleteRecurring);
    setShowModal(false);
    setSelectedShift(null);
  };

  const handleAdd = () => {
    setSelectedShift(null);
    setInitialHour(lastSettings.shiftDuration ? 9 : initialHour); // Use last duration if available
    setShowModal(true);
  };

  const handleNavigate = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    if (view === 'week') {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
    } else if (view === 'month') {
      newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
    } else {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
    }
    setSelectedDate(newDate);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Schedule</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage employee shifts and recurring appointments
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <ViewSelector view={view} onViewChange={setView} />
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="block w-48 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          >
            <option value="">All Roles</option>
            {roles.map(role => (
              <option key={role.id} value={role.id}>{role.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg">
        <CalendarHeader
          selectedDate={selectedDate}
          view={view}
          onNavigate={handleNavigate}
          onAddShift={handleAdd}
        />

        <div className="p-6">
          {view === 'timeline' && (
            <TimelineView
              selectedDate={selectedDate}
              employees={filteredEmployees}
              shifts={shifts}
              onShiftClick={handleEventClick}
            />
          )}

          {view === 'week' && (
            <WeekView
              days={daysToShow}
              employees={filteredEmployees}
              shifts={shifts}
              onShiftClick={handleEventClick}
            />
          )}

          {view === 'month' && (
            <MonthView
              days={daysToShow}
              selectedDate={selectedDate}
              employees={filteredEmployees}
              shifts={shifts}
              onShiftClick={handleEventClick}
            />
          )}
        </div>
      </div>

      {showModal && (
        <EditShiftForm
          onClose={() => setShowModal(false)}
          onSubmit={handleFormSubmit}
          onDelete={handleDelete}
          selectedShift={selectedShift}
          employees={employees}
          roles={roles}
          initialDate={selectedDate}
          initialHour={initialHour}
        />
      )}
    </div>
  );
}