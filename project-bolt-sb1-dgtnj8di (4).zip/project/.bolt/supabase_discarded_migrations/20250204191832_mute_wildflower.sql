-- Remove providers property from user metadata
CREATE OR REPLACE FUNCTION auth.handle_google_user()
RETURNS trigger AS $$
BEGIN
  -- Insert into public.users if not exists
  INSERT INTO public.users (
    id,
    email,
    first_name,
    last_name,
    role,
    color_code
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    'manager', -- Default to manager role for Google sign-ins
    '#10B981'  -- Default color code for managers
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update existing users to remove providers property
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data - 'providers'
WHERE raw_app_meta_data ? 'providers';

-- Update auth configuration
UPDATE auth.config
SET value = value - 'providers'
WHERE key = 'otp_settings' AND value ? 'providers';