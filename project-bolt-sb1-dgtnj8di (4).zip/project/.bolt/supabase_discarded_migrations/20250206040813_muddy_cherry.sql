-- Update auth configuration for Google provider
UPDATE auth.config
SET value = value || jsonb_build_object(
    'external_providers', jsonb_build_array(
        jsonb_build_object(
            'id', 'google',
            'enabled', true
        )
    )
)
WHERE key = 'auth.email';

-- Enable Google provider
INSERT INTO auth.providers (id, enabled)
VALUES ('google', true)
ON CONFLICT (id) DO UPDATE
SET enabled = true;

-- Add RLS policy for Google auth
CREATE POLICY "Allow Google authenticated users"
    ON auth.users
    FOR SELECT
    TO authenticated
    USING (
        auth.jwt()->>'aud' = 'authenticated' AND
        (auth.jwt()->'app_metadata'->>'provider')::text = 'google'
    );