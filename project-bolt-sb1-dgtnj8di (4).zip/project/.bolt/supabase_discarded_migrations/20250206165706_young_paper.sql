-- Create RLS policies
CREATE POLICY "users_read_policy"
    ON public.users
    FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "users_insert_policy"
    ON public.users
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

CREATE POLICY "users_update_policy"
    ON public.users
    FOR UPDATE
    TO authenticated
    USING (
        id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM auth.users au
            WHERE au.id = auth.uid()
            AND (au.raw_user_meta_data->>'role')::text = 'admin'
        )
    )
    WITH CHECK (
        id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM auth.users au
            WHERE au.id = auth.uid()
            AND (au.raw_user_meta_data->>'role')::text = 'admin'
        )
    );

CREATE POLICY "notifications_read_policy"
    ON public.notifications
    FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());