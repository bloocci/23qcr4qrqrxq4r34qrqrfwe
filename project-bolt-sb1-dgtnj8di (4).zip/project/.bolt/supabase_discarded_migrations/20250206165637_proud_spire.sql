-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create user_status type
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_status') THEN
        CREATE TYPE public.user_status AS ENUM (
            'active',
            'inactive'
        );
    END IF;
END $$;

-- Create users table
CREATE TABLE IF NOT EXISTS public.users (
    id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email text UNIQUE NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    role text NOT NULL CHECK (role IN ('admin', 'manager')),
    status user_status NOT NULL DEFAULT 'active',
    picture text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Create shifts table
CREATE TABLE IF NOT EXISTS public.shifts (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id uuid REFERENCES users(id) ON DELETE CASCADE,
    start_time timestamptz NOT NULL,
    end_time timestamptz NOT NULL,
    title text,
    notes text,
    type text DEFAULT 'regular',
    recurring_id uuid,
    recurring_days text,
    recurring_until timestamptz,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "users_read_policy"
    ON public.users
    FOR SELECT
    TO authenticated
    USING (true);  -- Allow all authenticated users to read

CREATE POLICY "users_update_policy"
    ON public.users
    FOR UPDATE
    TO authenticated
    USING (
        id = auth.uid() OR  -- Users can update their own data
        (SELECT raw_user_meta_data->>'role' FROM auth.users WHERE id = auth.uid()) = 'admin'  -- Admins can update any user
    );

CREATE POLICY "shifts_read_policy"
    ON public.shifts
    FOR SELECT
    TO authenticated
    USING (true);  -- All authenticated users can read shifts

CREATE POLICY "shifts_write_policy"
    ON public.shifts
    FOR ALL
    TO authenticated
    USING (
        (SELECT raw_user_meta_data->>'role' FROM auth.users WHERE id = auth.uid()) IN ('admin', 'manager')  -- Only admins and managers can modify shifts
    );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_shifts_employee_id ON public.shifts(employee_id);
CREATE INDEX IF NOT EXISTS idx_shifts_start_time ON public.shifts(start_time);
CREATE INDEX IF NOT EXISTS idx_shifts_recurring_id ON public.shifts(recurring_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON public.users(status);

-- Grant permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON public.users TO authenticated;
GRANT ALL ON public.shifts TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;