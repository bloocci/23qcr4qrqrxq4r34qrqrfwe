-- Create users table
CREATE TABLE IF NOT EXISTS public.users (
    id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email text UNIQUE NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    role text NOT NULL CHECK (role IN ('admin', 'manager')),
    status user_status NOT NULL DEFAULT 'pending',
    approved_by uuid REFERENCES auth.users(id),
    approved_at timestamptz,
    rejection_reason text,
    color_code text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);